"""
Queue operations for job lifecycle management.

Stateless operations that work on queue instance passed in.
"""

import itertools
import json
import os
import pickle
import sqlite3
import time
from typing import Optional

from shared.log import create_logger

log_trace, log_debug, log_info, log_warn, log_error = create_logger("Queue")

# Simple counter for job IDs (resets on restart, used for log correlation only)
_job_counter = itertools.count(1)

try:
    from persistqueue.sqlackqueue import SQLiteAckQueue as _SQLiteAckQueue
    from persistqueue.exceptions import Empty
except ImportError:
    _SQLiteAckQueue = None
    from queue import Empty  # fallback for tests


def enqueue(queue: 'persistqueue.SQLiteAckQueue', scene_id: int, update_type: str, data: dict) -> dict:
    """
    Enqueue a sync job.

    Args:
        queue: SQLiteAckQueue instance
        scene_id: Stash scene ID
        update_type: Type of update (e.g., "metadata", "image")
        data: Metadata to sync to Plex

    Returns:
        The enqueued job dict

    Example:
        >>> from persistqueue import SQLiteAckQueue
        >>> queue = SQLiteAckQueue('/tmp/queue')
        >>> job = enqueue(queue, scene_id=123, update_type='metadata',
        ...               data={'title': 'Example Scene'})
        >>> print(job['scene_id'])
        123
    """
    job = {
        'job_id': next(_job_counter),
        'scene_id': scene_id,
        'update_type': update_type,
        'data': data,
        'enqueued_at': time.time(),
        'job_key': f"scene_{scene_id}"
    }

    queue.put(job)
    log_trace(f"Enqueued sync job for scene {scene_id}")

    return job


def get_pending(queue: 'persistqueue.SQLiteAckQueue', timeout: float = 0) -> Optional[dict]:
    """
    Get next pending job from queue.

    Args:
        queue: SQLiteAckQueue instance
        timeout: Seconds to wait for job (0 = non-blocking)

    Returns:
        Job dict or None if timeout/empty
    """
    try:
        job = queue.get(timeout=timeout)
        return job
    except Empty:
        return None


def ack_job(queue: 'persistqueue.SQLiteAckQueue', job: dict):
    """
    Acknowledge successful job completion.

    Args:
        queue: SQLiteAckQueue instance
        job: Job dict from get_pending
    """
    queue.ack(job)
    jid = job.get('job_id', '?')
    log_trace(f"Job {jid} completed")


def nack_job(queue: 'persistqueue.SQLiteAckQueue', job: dict):
    """
    Return job to queue for retry.

    Args:
        queue: SQLiteAckQueue instance
        job: Job dict from get_pending
    """
    queue.nack(job)
    jid = job.get('job_id', '?')
    log_trace(f"Job {jid} returned to queue for retry")


def fail_job(queue: 'persistqueue.SQLiteAckQueue', job: dict):
    """
    Mark job as permanently failed.

    Args:
        queue: SQLiteAckQueue instance
        job: Job dict from get_pending
    """
    queue.ack_failed(job)
    jid = job.get('job_id', '?')
    log_debug(f"Job {jid} marked as failed")


def get_stats(queue_path: str) -> dict:
    """
    Get queue statistics by status.

    Queries SQLite database directly for status counts.

    Args:
        queue_path: Path to queue directory (contains data.db)

    Returns:
        Dict with status counts: {
            'pending': int,
            'in_progress': int,
            'completed': int,
            'failed': int
        }

    Status codes from persist-queue AckStatus enum:
        0 = inited
        1 = ready (pending)
        2 = unack (in_progress)
        5 = acked (completed)
        9 = ack_failed (failed)
    """
    db_path = os.path.join(queue_path, 'data.db')

    # Return zeros if database doesn't exist yet
    if not os.path.exists(db_path):
        return {
            'pending': 0,
            'in_progress': 0,
            'completed': 0,
            'failed': 0
        }

    conn = sqlite3.connect(db_path)
    try:
        # Find the ack_queue table (persist-queue uses ack_queue_default by default)
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'ack_queue%'"
        )
        table = cursor.fetchone()
        if not table:
            # Table doesn't exist yet (no jobs enqueued)
            return {
                'pending': 0,
                'in_progress': 0,
                'completed': 0,
                'failed': 0
            }

        table_name = table[0]

        cursor = conn.execute(f'''
            SELECT status, COUNT(*) as count
            FROM {table_name}
            GROUP BY status
        ''')

        stats = {
            'pending': 0,
            'in_progress': 0,
            'completed': 0,
            'failed': 0
        }

        for row in cursor:
            status_code = row[0]
            count = row[1]

            # Map status codes to categories
            # 0 and 1 are both "pending" (ready to process)
            if status_code in (0, 1):
                stats['pending'] += count
            elif status_code == 2:
                stats['in_progress'] += count
            elif status_code == 5:
                stats['completed'] += count
            elif status_code == 9:
                stats['failed'] += count

        return stats

    finally:
        conn.close()


def clear_pending_items(queue_path: str) -> int:
    """
    Clear all pending and stale in-progress items from queue.

    Deletes items with status 0 (inited), 1 (ready), or 2 (unack/in-progress).
    Status 2 items are from previous sessions where the worker was killed
    mid-processing — they would be auto-resumed and reprocessed otherwise.
    Does NOT delete completed (5) or failed (9) items.

    Args:
        queue_path: Path to queue directory (contains data.db)

    Returns:
        Number of items deleted
    """
    db_path = os.path.join(queue_path, 'data.db')

    if not os.path.exists(db_path):
        return 0

    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'ack_queue%'"
        )
        table = cursor.fetchone()
        if not table:
            return 0

        table_name = table[0]
        cursor = conn.execute(
            f"DELETE FROM {table_name} WHERE status IN (0, 1, 2)"
        )
        deleted = cursor.rowcount
        conn.commit()
        return deleted
    finally:
        conn.close()


def get_queued_scene_ids(queue_path: str, completed_window: float = 604800.0) -> set:
    """
    Get scene_ids for all items currently in queue (pending, in-progress, or recently completed).

    Queries SQLite directly and deserializes job data to extract scene_ids.
    Used for deduplication before batch enqueue operations.

    Includes recently-completed items (status=5) to prevent re-enqueue of scenes that
    were just processed in an ongoing batch.  Without this guard, a concurrent
    reconciliation or Sync-All run sees completed rows as "not in queue" and re-enqueues
    them, creating an infinite requeue loop.

    The completed_window uses the queue row's insertion timestamp (set when the job was
    first enqueued, not when it was acked), so it acts as a "was this scene touched in
    a recent batch?" check.  The default 7-day window (604800s) is generous enough to
    cover long-running sync sessions while allowing genuine re-syncs (scenes updated in
    Stash more than a week after their last queue entry) to pass through normally.
    Callers that need a persistent already-synced guard should additionally check
    sync_timestamps from load_sync_timestamps().

    Args:
        queue_path: Path to queue directory (contains data.db)
        completed_window: How far back (in seconds) to include completed items.
            Defaults to 604800 (7 days).  Pass 0 to skip completed rows entirely.

    Returns:
        Set of scene_id integers currently in queue (pending, in-progress, or recently completed)
    """
    db_path = os.path.join(queue_path, 'data.db')
    if not os.path.exists(db_path):
        return set()

    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'ack_queue%'"
        )
        table = cursor.fetchone()
        if not table:
            return set()

        table_name = table[0]

        # Always include pending (0, 1) and in-progress (2) rows.
        # Also include recently-completed (status=5) rows so that a concurrent
        # reconciliation or Sync-All run doesn't re-enqueue items that were just
        # processed — the root cause of the infinite requeue loop.
        if completed_window > 0:
            cutoff = time.time() - completed_window
            cursor = conn.execute(
                f"SELECT data FROM {table_name} "
                f"WHERE status IN (0, 1, 2) "
                f"OR (status = 5 AND timestamp > ?)",
                (cutoff,),
            )
        else:
            cursor = conn.execute(
                f"SELECT data FROM {table_name} WHERE status IN (0, 1, 2)"
            )

        scene_ids = set()
        for row in cursor:
            try:
                job = pickle.loads(row[0])
                sid = job.get('scene_id')
                if sid is not None:
                    scene_ids.add(int(sid))
            except Exception:
                continue
        return scene_ids
    finally:
        conn.close()


def _get_sync_timestamps_path(data_dir: str) -> str:
    """Get path to sync timestamps JSON file."""
    return os.path.join(data_dir, 'sync_timestamps.json')


def load_sync_timestamps(data_dir: str) -> dict[int, float]:
    """
    Load sync timestamps from JSON file.

    Args:
        data_dir: Queue data directory (same as queue_path)

    Returns:
        Dict mapping scene_id -> last_synced_at timestamp
    """
    path = _get_sync_timestamps_path(data_dir)
    if not os.path.exists(path):
        return {}

    try:
        with open(path, 'r') as f:
            data = json.load(f)
            # JSON keys are strings, convert back to int
            return {int(k): v for k, v in data.items()}
    except (json.JSONDecodeError, IOError):
        return {}


def save_sync_timestamp(data_dir: str, scene_id: int, timestamp: float) -> None:
    """
    Save sync timestamp for a scene.

    Args:
        data_dir: Queue data directory
        scene_id: Scene ID that was synced
        timestamp: time.time() when sync completed
    """
    path = _get_sync_timestamps_path(data_dir)

    # Load existing timestamps
    timestamps = load_sync_timestamps(data_dir)

    # Update with new timestamp
    timestamps[scene_id] = timestamp

    # Write back atomically (write to temp, rename)
    temp_path = path + '.tmp'
    with open(temp_path, 'w') as f:
        json.dump(timestamps, f)
    os.replace(temp_path, path)
