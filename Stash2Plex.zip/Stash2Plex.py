#!/usr/bin/env python3
"""
Stash2Plex - Stash plugin for syncing metadata to Plex

Entry point for the Stash plugin. Initializes queue infrastructure,
starts background worker, and handles Stash hooks.
"""

import os
import sys
import json
import time


from shared.log import create_logger, create_progress_logger
log_trace, log_debug, log_info, log_warn, log_error = create_logger()
log_progress = create_progress_logger()


log_trace("Script starting...")

# Add plugin directory to path for imports
PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
if PLUGIN_DIR not in sys.path:
    sys.path.insert(0, PLUGIN_DIR)

log_trace(f"PLUGIN_DIR: {PLUGIN_DIR}")

# --- Dependency installation (driven by requirements.txt) ---
# Override map for packages where names don't follow standard conventions.
# Standard convention: import name = pip name with hyphens replaced by underscores.
# Format: requirements.txt name → (import_name, pip_install_name)
_PKG_NAMES = {
    "persist-queue": ("persistqueue", "persist-queue"),
    "stashapp-tools": ("stashapi", "stashapp-tools"),
}


def _parse_requirements():
    """Parse requirements.txt → [(import_name, pip_spec), ...]"""
    path = os.path.join(PLUGIN_DIR, "requirements.txt")
    deps = []
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                # Split "package>=1.0.0" → base name + version specifier
                for i, ch in enumerate(line):
                    if ch in ">=<!~":
                        req_name, ver_spec = line[:i], line[i:]
                        break
                else:
                    req_name, ver_spec = line, ""
                import_name, pip_name = _PKG_NAMES.get(
                    req_name, (req_name.replace("-", "_"), req_name)
                )
                deps.append((import_name, pip_name + ver_spec))
    except FileNotFoundError:
        log_warn(f"requirements.txt not found at {path}")
    return deps


def _check_missing(deps):
    """Return deps where the module can't be imported."""
    missing = []
    for import_name, pip_spec in deps:
        try:
            __import__(import_name)
        except ImportError:
            missing.append((import_name, pip_spec))
    return missing


_required_deps = _parse_requirements()

# Step 1: Try PythonDepManager (Stash's built-in package manager)
try:
    from PythonDepManager import ensure_import
    log_trace("Installing dependencies via PythonDepManager...")
    # Build ensure_import args: "import_name:pip_spec" when names differ
    _ei_args = []
    for _imp, _pip in _required_deps:
        _pip_base = _pip
        for _ch in ">=<!~":
            _idx = _pip_base.find(_ch)
            if _idx >= 0:
                _pip_base = _pip_base[:_idx]
                break
        if _imp == _pip_base or _imp == _pip_base.replace("-", "_"):
            _ei_args.append(_pip)
        else:
            _ei_args.append(f"{_imp}:{_pip}")
    ensure_import(*_ei_args)
    log_trace("Dependencies installed via PythonDepManager")
except ImportError:
    log_trace("PythonDepManager not available")
except Exception as e:
    log_warn(f"PythonDepManager failed: {e}")

# Step 2: Verify deps and fallback to pip if any are missing
_missing = _check_missing(_required_deps)
if _missing:
    log_trace(f"Missing after PythonDepManager: {[m for m, _ in _missing]}")
    log_trace(f"Attempting pip install with: {sys.executable}")
    import subprocess
    for _mod, _pkg in _missing:
        try:
            _result = subprocess.run(
                [sys.executable, "-m", "pip", "install",
                 "--break-system-packages", _pkg],
                capture_output=True, text=True, timeout=120,
            )
            if _result.returncode == 0:
                log_trace(f"Installed {_pkg}")
            else:
                log_warn(f"pip install {_pkg} failed: {_result.stderr.strip()}")
        except Exception as e:
            log_warn(f"pip install {_pkg} failed: {e}")

# Step 3: Final verification — actionable error if still missing
_still_missing = _check_missing(_required_deps)
if _still_missing:
    _names = [m for m, _ in _still_missing]
    _pkgs = [p for _, p in _still_missing]
    _pip_cmd = f"{sys.executable} -m pip install --break-system-packages {' '.join(_pkgs)}"
    log_error(f"Missing required dependencies: {_names}")
    log_error(f"Stash is using Python: {sys.executable}")
    log_error(f"To fix, run: {_pip_cmd}")
    print(json.dumps({
        "error": f"Missing dependencies: {', '.join(_names)}. "
                 f"Install with: {_pip_cmd}"
    }))
    sys.exit(1)

try:
    from sync_queue.manager import QueueManager
    from sync_queue.dlq import DeadLetterQueue
    from sync_queue.operations import load_sync_timestamps
    from worker.processor import SyncWorker
    from hooks.handlers import on_scene_update
    from validation.config import validate_config, Stash2PlexConfig
    from plex.device_identity import configure_plex_device_identity
    log_trace("All imports successful")
except ImportError as e:
    log_error(f"Import error: {e}")
    import traceback
    traceback.print_exc()
    print(json.dumps({"error": str(e)}))
    sys.exit(1)

# Globals (initialized in main)
queue_manager = None
dlq = None
worker = None
config: Stash2PlexConfig = None
sync_timestamps: dict = None
stash_interface = None


def get_plugin_data_dir():
    """
    Get or create plugin data directory.

    Returns:
        Path to plugin data directory
    """
    # Check for Stash-provided path first
    data_dir = os.getenv('STASH_PLUGIN_DATA')
    if not data_dir:
        # Default to plugin_dir/data
        data_dir = os.path.join(PLUGIN_DIR, 'data')

    os.makedirs(data_dir, exist_ok=True)
    return data_dir


class DirectStashInterface:
    """
    Stdlib-only drop-in replacement for stashapi.StashInterface.

    Uses urllib to make GraphQL calls directly so the plugin works even
    when the stashapp-tools/stashapi pip package is broken or conflicted.
    Implements the subset of StashInterface methods used by this plugin.
    """

    def __init__(self, server_conn: dict):
        scheme = server_conn.get('Scheme', server_conn.get('scheme', 'http'))
        host = server_conn.get('Host', server_conn.get('host', '127.0.0.1'))
        port = server_conn.get('Port', server_conn.get('port', 9999))
        self._url = f"{scheme}://{host}:{port}/graphql"
        self._headers = {'Content-Type': 'application/json'}
        session_cookie = server_conn.get('SessionCookie', {})
        if isinstance(session_cookie, dict) and session_cookie.get('Value'):
            name = session_cookie.get('Name', 'session')
            self._headers['Cookie'] = f"{name}={session_cookie['Value']}"
        api_key = server_conn.get('ApiKey', '')
        if api_key:
            self._headers['ApiKey'] = api_key

    def _gql(self, query: str, variables: dict = None) -> dict:
        import urllib.request
        payload = json.dumps({'query': query, 'variables': variables or {}}).encode()
        req = urllib.request.Request(self._url, data=payload, headers=self._headers)
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        if 'errors' in data:
            raise RuntimeError(data['errors'])
        return data.get('data', {})

    def call_GQL(self, query: str, variables: dict = None) -> dict:
        return self._gql(query, variables)

    def _callGraphQL(self, query: str, variables: dict = None) -> dict:
        return self._gql(query, variables)

    def get_configuration(self) -> dict:
        data = self._gql('{ configuration { plugins } }')
        return data.get('configuration', {})

    def find_scene(self, scene_id) -> dict:
        query = """
            query FindScene($id: ID!) {
                findScene(id: $id) {
                    id title details urls date rating100
                    files { path }
                    paths { screenshot stream }
                    studio { id name image_path parent_studio { id name details } }
                    performers { name image_path tags { id name } }
                    tags { id name }
                    stash_ids { stash_id endpoint }
                    organized
                    movies { movie { id name } }
                    galleries { id title url }
                }
            }
        """
        data = self._gql(query, {'id': scene_id})
        return data.get('findScene')

    def find_scenes(self, f: dict = None, fragment: str = None, filter: dict = None) -> list:
        """Paginate through all matching scenes and return them."""
        scene_fields = fragment or "id title updated_at files { path }"
        scene_filter_arg = ', $scene_filter: SceneFilterType' if f else ''
        scene_filter_use = ', scene_filter: $scene_filter' if f else ''
        query = f"""
            query FindScenes($filter: FindFilterType{scene_filter_arg}) {{
                findScenes(filter: $filter{scene_filter_use}) {{
                    count
                    scenes {{ {scene_fields} }}
                }}
            }}
        """
        per_page = 1000
        page = 1
        all_scenes = []
        while True:
            variables = {'filter': {'per_page': per_page, 'page': page}}
            if f:
                variables['scene_filter'] = f
            data = self._gql(query, variables)
            result = data.get('findScenes', {})
            scenes = result.get('scenes', [])
            all_scenes.extend(scenes)
            if len(all_scenes) >= result.get('count', 0) or not scenes:
                break
            page += 1
        return all_scenes


def get_stash_interface(input_data: dict):
    """
    Create StashInterface from input data.

    Tries stashapi.StashInterface first; falls back to DirectStashInterface
    (stdlib-only) if the package is broken or missing.

    Returns:
        StashInterface or DirectStashInterface instance, never None
        (as long as server_connection is present in input_data).
    """
    conn = input_data.get('server_connection', {})
    if not conn:
        return None
    try:
        from stashapi.stashapp import StashInterface
        return StashInterface(conn)
    except Exception as e:
        log_debug(f" stashapi unavailable ({e}), using DirectStashInterface")
    return DirectStashInterface(conn)


def fetch_plugin_settings_direct(server_conn: dict) -> dict:
    """
    Fetch Stash2Plex plugin settings via a raw urllib GraphQL request.

    Uses only stdlib so it works even if stashapi/stashapp-tools is broken
    or not yet installed. Called as the primary config path; stash.get_configuration()
    is only used when this fails.

    Args:
        server_conn: server_connection dict from Stash plugin input

    Returns:
        Dictionary with plugin settings, or {} on failure
    """
    import urllib.request
    import urllib.error

    scheme = server_conn.get('Scheme', server_conn.get('scheme', 'http'))
    host = server_conn.get('Host', server_conn.get('host', '127.0.0.1'))
    port = server_conn.get('Port', server_conn.get('port', 9999))
    url = f"{scheme}://{host}:{port}/graphql"

    query = '{"query":"{ configuration { plugins } }"}'
    req = urllib.request.Request(
        url,
        data=query.encode(),
        headers={'Content-Type': 'application/json'},
    )

    # Add auth if available
    session_cookie = server_conn.get('SessionCookie', {})
    if isinstance(session_cookie, dict) and session_cookie.get('Value'):
        name = session_cookie.get('Name', 'session')
        req.add_header('Cookie', f"{name}={session_cookie['Value']}")
    api_key = server_conn.get('ApiKey', '')
    if api_key:
        req.add_header('ApiKey', api_key)

    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
        plugins = data.get('data', {}).get('configuration', {}).get('plugins', {})
        return plugins.get('Stash2Plex', {})
    except Exception as e:
        log_warn(f" Direct config fetch failed: {e}")
        return {}


def fetch_plugin_settings(stash) -> dict:
    """
    Fetch Stash2Plex plugin settings from Stash configuration.

    Args:
        stash: StashInterface instance

    Returns:
        Dictionary with plugin settings
    """
    if not stash:
        return {}

    try:
        config = stash.get_configuration()
        plugins = config.get('plugins', {})
        return plugins.get('Stash2Plex', {})
    except Exception as e:
        log_warn(f" Could not fetch settings from Stash: {e}")
        return {}


def extract_config_from_input(input_data: dict, existing_stash=None) -> dict:
    """
    Extract Plex configuration from Stash input data.

    Fetches plugin settings from Stash GraphQL API using stashapi,
    then falls back to environment variables.

    Args:
        input_data: Input data from Stash plugin protocol
        existing_stash: Optional pre-existing StashInterface to reuse.
            When provided, avoids creating a duplicate connection to Stash
            (which would make an extra 2 GQL calls for version + apiKey checks).
            Pass the temp_stash created for scan detection in hook invocations.

    Returns:
        Dictionary with config values (may be empty if nothing found)
    """
    global stash_interface
    config_dict = {}

    # Extract Stash connection info for image fetching
    server_conn = input_data.get('server_connection', {})
    if server_conn:
        scheme = server_conn.get('Scheme', server_conn.get('scheme', 'http'))
        host = server_conn.get('Host', server_conn.get('host', '127.0.0.1'))
        port = server_conn.get('Port', server_conn.get('port', 9999))
        config_dict['stash_url'] = f"{scheme}://{host}:{port}"

        # Get session cookie/API key for authentication
        session_cookie = server_conn.get('SessionCookie', {})
        if session_cookie:
            if isinstance(session_cookie, dict):
                cookie_name = session_cookie.get('Name', 'session')
                cookie_value = session_cookie.get('Value', '')
                config_dict['stash_session_cookie'] = f"{cookie_name}={cookie_value}"
            else:
                config_dict['stash_session_cookie'] = str(session_cookie)

        api_key = server_conn.get('ApiKey', server_conn.get('apiKey', ''))
        if api_key:
            config_dict['stash_api_key'] = api_key

    # Primary path: direct urllib GraphQL call (stdlib only, immune to stashapi install issues).
    if server_conn:
        stash_settings = fetch_plugin_settings_direct(server_conn)
        if stash_settings:
            log_trace(f"Loaded settings from Stash (direct): {list(stash_settings.keys())}")
            config_dict.update(stash_settings)

    # Secondary path: StashInterface (provides richer API for hook handlers).
    # Reuse existing connection if provided to avoid duplicate GQL calls.
    if existing_stash is not None:
        stash = existing_stash
    else:
        stash = get_stash_interface(input_data)
    stash_interface = stash  # Store globally for hook handlers
    if stash and not config_dict.get('plex_url'):
        # Only call if direct fetch didn't already get settings
        stash_settings = fetch_plugin_settings(stash)
        if stash_settings:
            log_trace(f"Loaded settings from Stash (StashInterface): {list(stash_settings.keys())}")
            config_dict.update(stash_settings)

    # Fallback to environment variables
    if 'plex_url' not in config_dict:
        env_url = os.getenv('PLEX_URL')
        if env_url:
            config_dict['plex_url'] = env_url

    if 'plex_token' not in config_dict:
        env_token = os.getenv('PLEX_TOKEN')
        if env_token:
            config_dict['plex_token'] = env_token

    return config_dict


def initialize(config_dict: dict = None, resume_orphaned: bool = True, start_worker: bool = True):
    """
    Initialize queue, DLQ, and worker with validated configuration.

    Args:
        config_dict: Optional configuration dictionary. If not provided,
                     will attempt to read from environment variables.
        resume_orphaned: If True (default), resume orphaned in-progress items
                         from prior crashed processes. Pass False for hook
                         invocations to prevent a stale orphaned item (e.g.,
                         a scene not yet scanned by Plex) from monopolizing the
                         10-second hook window and blocking all newer jobs.
                         Orphaned items accumulate safely (status=2 is skipped
                         by the queue) and are recovered on the next task run.

    Returns:
        False if configuration validation fails, True otherwise
    """
    log_trace("initialize() called")
    global queue_manager, dlq, worker, config, sync_timestamps

    # Validate configuration
    if config_dict is None:
        config_dict = {}

    # If no config provided, try environment variables as fallback
    if not config_dict:
        env_url = os.getenv('PLEX_URL')
        env_token = os.getenv('PLEX_TOKEN')
        if env_url:
            config_dict['plex_url'] = env_url
        if env_token:
            config_dict['plex_token'] = env_token

    log_trace(f"Validating config: {list(config_dict.keys())}")
    try:
        validated_config, error = validate_config(config_dict)
    except Exception as e:
        log_error(f"validate_config exception: {e}")
        import traceback
        traceback.print_exc()
        return False

    if error:
        log_error(f"Configuration error: {error}")
        return False

    config = validated_config

    # Configure path obfuscation (must be before any logging that includes paths)
    from validation.obfuscation import configure_obfuscation
    configure_obfuscation(getattr(config, 'obfuscate_paths', False))

    # Log configuration summary (includes debug_logging startup warning)
    config.log_config()

    # Check if plugin is disabled
    if not config.enabled:
        log_info("Plugin is disabled via configuration")
        return True

    data_dir = get_plugin_data_dir()

    # Configure persistent Plex device identity (must be before PlexClient creation)
    device_id = configure_plex_device_identity(data_dir)
    log_trace(f"Using Plex device ID: {device_id[:8]}...")

    # Load sync timestamps for late update detection
    sync_timestamps = load_sync_timestamps(data_dir)
    log_trace(f"Loaded {len(sync_timestamps)} sync timestamps")

    # Initialize queue infrastructure
    queue_manager = QueueManager(data_dir)
    dlq = DeadLetterQueue(data_dir)

    worker = SyncWorker(
        queue_manager,
        dlq,
        config,
        data_dir=data_dir,
        max_retries=config.max_retries
    )

    if start_worker:
        if worker.try_start_exclusive(resume_orphaned=resume_orphaned):
            log_info("Initialization complete (worker started)")
        else:
            log_info("Initialization complete (worker deferred — another process is draining)")
    else:
        log_trace("Initialization complete (hook mode, worker not started)")

    return True


def shutdown():
    """Clean shutdown of worker and queue."""
    global worker, queue_manager

    if worker:
        worker.stop()  # stop() also releases the exclusion lock

    if queue_manager:
        queue_manager.shutdown()

    log_trace("Shutdown complete")


def trigger_plex_scan_for_scene(scene_id: int, stash) -> bool:
    """
    Trigger a Plex library scan for a scene's file location.

    Args:
        scene_id: Stash scene ID
        stash: StashInterface for API calls

    Returns:
        True if scan was triggered, False otherwise
    """
    if not config or not config.trigger_plex_scan:
        return False

    libraries = config.plex_libraries
    if not libraries:
        log_warn("trigger_plex_scan enabled but plex_library not set")
        return False

    if not stash:
        log_warn("No Stash connection available for scene lookup")
        return False

    try:
        # Get scene file path
        scene = stash.find_scene(scene_id)
        if not scene:
            log_warn(f"Scene {scene_id} not found")
            return False

        files = scene.get('files', [])
        if not files:
            log_warn(f"Scene {scene_id} has no files")
            return False

        file_path = files[0].get('path')
        if not file_path:
            log_warn(f"Scene {scene_id} file has no path")
            return False

        # Get the parent directory for partial scan
        import os
        scan_path = os.path.dirname(file_path)

        # Create Plex client and trigger scan
        from plex.client import PlexClient
        plex_client = PlexClient(
            url=config.plex_url,
            token=config.plex_token,
            connect_timeout=config.plex_connect_timeout,
            read_timeout=config.plex_read_timeout
        )

        # Scan all configured libraries
        for lib_name in libraries:
            try:
                plex_client.scan_library(lib_name, path=scan_path)
                log_info(f"Triggered Plex scan of '{lib_name}' for: {scan_path}")
            except Exception as e:
                log_warn(f"Failed to scan library '{lib_name}': {e}")
        return True

    except Exception as e:
        from plex.exceptions import PlexServerDown
        if isinstance(e, PlexServerDown):
            log_warn("Plex server is down — scene queued, will sync when Plex is back")
        else:
            log_error(f"Failed to trigger Plex scan: {e}")
        return False


def _trigger_async_queue_drain(server_connection: dict | None = None):
    """Fire-and-forget queue drain for deferred identify-hook jobs."""
    try:
        from sync_queue.drain_trigger import QueueDrainTrigger

        trigger = QueueDrainTrigger(
            plugin_dir=PLUGIN_DIR,
            data_dir=get_plugin_data_dir(),
            python_executable=sys.executable,
        )
        result = trigger.trigger(server_connection)
        if result.triggered:
            log_trace(f"Triggered async process_queue drain from identify hook (pid={result.pid})")
        else:
            log_trace(f"Async process_queue drain not started ({result.reason})")
        return result
    except Exception as e:
        log_debug(f'Async queue drain trigger failed: {e}')
        return None


def handle_hook(hook_context: dict, stash=None, server_connection=None):
    """
    Handle incoming Stash hook.

    Expected hook_context structure:
    {
        "type": "Scene.Update.Post",
        "input": {...scene update data...}
    }

    Args:
        hook_context: Hook context from Stash
        stash: StashInterface for API calls
    """
    global sync_timestamps

    hook_type = hook_context.get("type", "")
    # Scene ID is at top level of hookContext, not inside input
    scene_id = hook_context.get("id")
    input_data = hook_context.get("input") or {}

    log_trace(f"handle_hook: type={hook_type}, scene_id={scene_id}")

    # Strict mode: only act on identification-complete events.
    # This avoids any plugin overhead on generic save/edit/scan updates.
    if hook_type != "Scene.Update.Post" or 'stash_ids' not in input_data:
        log_trace(f"Skipping hook {hook_type} — only Scene.Update.Post with stash_ids is processed")
        return

    if not scene_id:
        log_warn(f"{hook_type} identification hook missing scene ID")
        return

    log_debug(f"Scene {scene_id} identified via stash-box")

    # Identification hook must stay non-blocking: no Plex scan and no scene fetch.
    # We enqueue a deferred job; hydration + sync run later in task/worker paths.
    data_dir = get_plugin_data_dir()
    try:
        enqueued = on_scene_update(
            scene_id,
            input_data,
            queue_manager,
            data_dir=data_dir,
            sync_timestamps=sync_timestamps,
            stash=stash,
            is_identification=True,
            scan_already_checked=True,
            defer_scene_fetch=True,
        )
        # Identification hooks are the signal that queue work may be waiting.
        # Trigger even when enqueue returned False, because False can mean
        # "already_pending"; that still needs a drainer if none is active.
        _trigger_async_queue_drain(server_connection)
        if enqueued:
            log_info(f"Identify hook deferred+enqueued for scene {scene_id}")
        else:
            log_info(f"Identify hook skipped enqueue for scene {scene_id}")
        log_trace(f"on_scene_update completed for scene {scene_id}")
    except Exception as e:
        log_error(f"on_scene_update exception: {e}")
        import traceback
        traceback.print_exc()


def handle_queue_status():
    """Display current queue and DLQ statistics."""
    try:
        data_dir = get_plugin_data_dir()
        queue_path = os.path.join(data_dir, 'queue')

        from sync_queue.operations import get_stats
        from sync_queue.dlq import DeadLetterQueue

        stats = get_stats(queue_path)
        dlq = DeadLetterQueue(data_dir)
        dlq_count = dlq.get_count()
        dlq_summary = dlq.get_error_summary()

        log_info("=== Queue Status ===")
        log_info(f"Pending: {stats['pending']}")
        log_info(f"In Progress: {stats['in_progress']}")
        log_info(f"Completed: {stats['completed']}")
        log_info(f"Failed (queue): {stats['failed']}")
        log_info(f"Dead Letter Queue: {dlq_count} items")

        if dlq_summary:
            log_info("DLQ Error Breakdown:")
            for error_type, count in dlq_summary.items():
                log_info(f"  {error_type}: {count}")

        # Reconciliation status (RPT-01)
        try:
            from reconciliation.scheduler import ReconciliationScheduler
            scheduler = ReconciliationScheduler(data_dir)
            state = scheduler.load_state()

            log_info("=== Reconciliation Status ===")
            if state.last_run_time > 0:
                import datetime
                last_run_dt = datetime.datetime.fromtimestamp(state.last_run_time)
                log_info(f"Last run: {last_run_dt.strftime('%Y-%m-%d %H:%M:%S')}")
                log_info(f"Scope: {state.last_run_scope}")
                log_info(f"Scenes checked: {state.last_scenes_checked}")
                log_info(f"Gaps found: {state.last_gaps_found}")
                if state.last_gaps_by_type:
                    log_info(f"  Empty metadata: {state.last_gaps_by_type.get('empty_metadata', 0)}")
                    log_info(f"  Stale sync: {state.last_gaps_by_type.get('stale_sync', 0)}")
                    log_info(f"  Missing from Plex: {state.last_gaps_by_type.get('missing', 0)}")
                log_info(f"Enqueued: {state.last_enqueued}")
                if state.is_startup_run:
                    log_info("(Triggered by startup)")
                log_info(f"Total reconciliation runs: {state.run_count}")
            else:
                log_info("No reconciliation runs yet")
        except Exception as e:
            log_debug(f"Failed to load reconciliation status: {e}")

        # Load circuit breaker status once — used by CB, Recovery, and Outage sections
        from worker.circuit_breaker import CircuitBreaker
        from worker.outage_history import format_duration, format_elapsed_since
        cb_file = os.path.join(data_dir, 'circuit_breaker.json')
        cb_status = CircuitBreaker.load_status(cb_file)

        # Circuit Breaker Status (VISB-01)
        try:
            log_info("=== Circuit Breaker Status ===")
            log_info(f"State: {cb_status['state'].upper()}")
            if cb_status['is_open'] and cb_status['opened_at']:
                log_info(f"Opened: {format_elapsed_since(cb_status['opened_at'])}")
                log_info(f"Duration: {format_duration(time.time() - cb_status['opened_at'])}")
            elif cb_status['state'] == 'half_open':
                log_info("Testing recovery...")
        except Exception as e:
            log_debug(f"Failed to load circuit breaker status: {e}")

        # Recovery Status (VISB-01)
        try:
            from worker.recovery import RecoveryScheduler
            recovery_scheduler = RecoveryScheduler(data_dir)
            recovery_state = recovery_scheduler.load_state()

            log_info("=== Recovery Status ===")
            if recovery_state.last_check_time > 0:
                log_info(f"Last health check: {format_elapsed_since(recovery_state.last_check_time)}")
                if cb_status['is_open']:
                    elapsed = time.time() - recovery_state.last_check_time
                    next_check_in = max(0, 5.0 - elapsed)
                    log_info(f"Next check: in {next_check_in:.0f}s")
            else:
                log_info("No health checks yet")

            if recovery_state.last_recovery_time > 0:
                log_info(f"Last recovery: {format_elapsed_since(recovery_state.last_recovery_time)}")

            log_info(f"Total recoveries: {recovery_state.recovery_count}")
        except Exception as e:
            log_debug(f"Failed to load recovery status: {e}")

        # Recent Outages (VISB-01)
        try:
            from worker.outage_history import OutageHistory
            log_info("=== Recent Outages ===")
            history = OutageHistory(data_dir)
            records = history.get_history()

            if records:
                for record in records[-3:]:
                    if record.ended_at is None:
                        elapsed = time.time() - record.started_at
                        if cb_status['is_closed']:
                            # Orphaned: circuit is CLOSED so outage resolved, record never closed
                            log_info(f"Duration: ~{format_duration(elapsed)} (resolved — circuit closed)")
                        else:
                            log_info(f"ONGOING ({format_duration(elapsed)})")
                    else:
                        log_info(f"Duration: {format_duration(record.duration)}")

                current = history.get_current_outage()
                if current and cb_status['is_open']:
                    elapsed = time.time() - current.started_at
                    log_info(f"Current outage: {format_duration(elapsed)}")
            else:
                log_info("No outages recorded")
        except Exception as e:
            log_debug(f"Failed to load outage history: {e}")

    except Exception as e:
        log_error(f"Failed to get queue status: {e}")
        import traceback
        traceback.print_exc()


def handle_clear_match_cache():
    """Clear the match cache to force fresh Plex lookups on next sync."""
    try:
        data_dir = get_plugin_data_dir()
        from plex.cache import MatchCache
        cache_dir = os.path.join(data_dir, 'cache')
        cache = MatchCache(cache_dir)
        stats = cache.get_stats()
        count = stats['count']
        if count == 0:
            log_info("Match cache is already empty")
        else:
            cache.clear()
            log_info(f"Cleared {count} entries from match cache — next sync will re-match all items from Plex")
        cache.close()
    except Exception as e:
        log_error(f"Failed to clear match cache: {e}")
        import traceback
        traceback.print_exc()


def handle_clear_queue():
    """Clear all pending queue items."""
    try:
        data_dir = get_plugin_data_dir()
        queue_path = os.path.join(data_dir, 'queue')

        from sync_queue.operations import get_stats, clear_pending_items

        before_stats = get_stats(queue_path)
        pending = before_stats['pending']

        if pending == 0:
            log_info("Queue is empty - nothing to clear")
            return

        log_warn(f"Clearing {pending} pending queue items...")
        deleted = clear_pending_items(queue_path)
        log_info(f"Successfully cleared {deleted} pending items from queue")

        after_stats = get_stats(queue_path)
        log_info(f"Remaining - Pending: {after_stats['pending']}, In Progress: {after_stats['in_progress']}")

    except Exception as e:
        log_error(f"Failed to clear queue: {e}")
        import traceback
        traceback.print_exc()


def handle_clear_dlq():
    """Clear all items from dead letter queue."""
    try:
        data_dir = get_plugin_data_dir()

        from sync_queue.dlq import DeadLetterQueue
        dlq = DeadLetterQueue(data_dir)

        count_before = dlq.get_count()

        if count_before == 0:
            log_info("Dead letter queue is empty - nothing to clear")
            return

        log_warn(f"Clearing {count_before} items from dead letter queue...")

        with dlq._get_connection() as conn:
            cursor = conn.execute("DELETE FROM dead_letters")
            deleted = cursor.rowcount
            conn.commit()

        log_info(f"Successfully cleared {deleted} items from DLQ")

    except Exception as e:
        log_error(f"Failed to clear DLQ: {e}")
        import traceback
        traceback.print_exc()


def handle_purge_dlq(days: int = 30):
    """Remove DLQ entries older than specified days."""
    try:
        data_dir = get_plugin_data_dir()

        from sync_queue.dlq import DeadLetterQueue
        dlq = DeadLetterQueue(data_dir)

        count_before = dlq.get_count()
        log_info(f"Purging DLQ entries older than {days} days...")

        dlq.delete_older_than(days)

        count_after = dlq.get_count()
        removed = count_before - count_after

        log_info(f"Removed {removed} old DLQ entries ({count_after} remain)")

    except Exception as e:
        log_error(f"Failed to purge old DLQ entries: {e}")
        import traceback
        traceback.print_exc()


def handle_process_queue():
    """
    Process all pending queue items synchronously until the queue is empty.

    Delegates entirely to SyncWorker.run_batch(), which shares all retry,
    DLQ, dedup, and backoff logic with the background worker loop.
    """
    global config, worker, queue_manager, dlq

    try:
        data_dir = get_plugin_data_dir()

        # Stop the background worker so it doesn't compete for queue items
        if worker:
            worker.stop()

        # Configure device identity before any Plex operations
        configure_plex_device_identity(data_dir)

        from worker.processor import SyncWorker
        worker_local = SyncWorker(queue_manager, dlq, config, data_dir=data_dir)

        # Optional throughput tuning for large backlog drains.
        # Env override example: STASH2PLEX_BATCH_JOB_DELAY_SECS=0.03
        job_delay_secs = 0.15
        try:
            env_delay = os.getenv('STASH2PLEX_BATCH_JOB_DELAY_SECS')
            if env_delay is not None and env_delay.strip() != '':
                job_delay_secs = max(0.0, float(env_delay))
        except Exception:
            log_warn("Invalid STASH2PLEX_BATCH_JOB_DELAY_SECS value, using default 0.15s")
            job_delay_secs = 0.15

        log_info(f"Process queue batch delay: {job_delay_secs:.3f}s")
        worker_local.run_batch(progress_callback=log_progress, job_delay_secs=job_delay_secs)

    except Exception as e:
        log_error(f"Process queue error: {e}")
        import traceback
        traceback.print_exc()


def handle_reconcile(scope: str):
    """
    Run gap detection and enqueue discovered gaps for sync.

    Args:
        scope: "all" (all scenes), "recent" (last 24 hours), or "recent_7days" (last 7 days)
    """
    try:
        data_dir = get_plugin_data_dir()

        if not stash_interface:
            log_error("No Stash connection available for reconciliation")
            return
        if not config:
            log_error("No config available for reconciliation")
            return

        if queue_manager is None:
            log_warn("No queue available - running in detection-only mode")

        scope_labels = {
            "all": "all scenes",
            "recent": "scenes added in last 24 hours",
            "missing_metadata": "scenes with missing Plex metadata (all scenes)",
            "recent_7days": "scenes added in last 7 days",
        }
        log_info(f"Starting reconciliation: {scope_labels.get(scope, scope)}")

        from reconciliation.runner import ReconciliationRunner
        runner = ReconciliationRunner(stash_interface, config, data_dir, queue_manager)
        runner.run(scope=scope)

        # Automation: immediately drain whatever reconciliation enqueued.
        # This makes reconcile tasks self-contained (detect + fix) so users
        # don't have to manually run Process Queue afterwards.
        log_info("Reconciliation complete — auto-draining queue now")
        handle_process_queue()

    except Exception as e:
        log_error(f"Reconciliation failed: {e}")
        import traceback
        traceback.print_exc()


def maybe_check_recovery():
    """Check if recovery detection is due and run it if so.

    Called on every plugin invocation (hook or task) BEFORE maybe_auto_reconcile().
    If circuit breaker is OPEN/HALF_OPEN and check interval has elapsed, probes
    Plex health and transitions circuit breaker state based on result.

    This is a lightweight check when circuit is CLOSED (reads circuit state only).
    Only creates PlexClient and runs health check when recovery probe is actually due.
    """
    if not config or not worker:
        return

    try:
        # Quick check: if circuit is CLOSED, nothing to recover
        circuit_state = worker.circuit_breaker.state
        from worker.circuit_breaker import CircuitState
        if circuit_state == CircuitState.CLOSED:
            return

        data_dir = get_plugin_data_dir()
        from worker.recovery import RecoveryScheduler
        from worker.outage_history import OutageHistory

        outage_history = OutageHistory(data_dir)
        scheduler = RecoveryScheduler(data_dir, outage_history=outage_history)

        if not scheduler.should_check_recovery(circuit_state):
            return

        # Recovery probe is due - run health check
        from plex.client import PlexClient
        from plex.health import check_plex_health

        client = PlexClient(
            url=config.plex_url,
            token=config.plex_token,
            connect_timeout=5.0,
            read_timeout=5.0
        )

        is_healthy, latency_ms = check_plex_health(client, timeout=5.0)
        scheduler.record_health_check(is_healthy, latency_ms, worker.circuit_breaker)

        # Log queue drain info if recovery completed
        if is_healthy and worker.circuit_breaker.state == CircuitState.CLOSED:
            pending = queue_manager.get_queue().size if queue_manager else 0
            if pending > 0:
                log_info(f"Queue will drain automatically ({pending} jobs pending)")

    except Exception as e:
        log_debug(f"Recovery check failed: {e}")


def maybe_auto_reconcile():
    """Check if auto-reconciliation is due and run it if so.

    Called on every plugin invocation (hook or task). Checks:
    1. If this is the first invocation since Stash startup -> run recent scope
    2. If reconcile_interval has elapsed -> run configured scope

    This is a lightweight check (reads one JSON file) that only triggers
    the heavier gap detection when reconciliation is actually due.
    """
    if not config or config.reconcile_interval == 'never':
        return

    if not stash_interface or not queue_manager:
        return

    try:
        data_dir = get_plugin_data_dir()
        from reconciliation.scheduler import ReconciliationScheduler

        scheduler = ReconciliationScheduler(data_dir)

        from reconciliation.runner import ReconciliationRunner

        # Check startup trigger first (AUTO-02)
        if scheduler.is_startup_due():
            log_info("Auto-reconciliation: startup trigger (recent scenes)")
            ReconciliationRunner(stash_interface, config, data_dir, queue_manager).run(
                scope="recent", is_startup=True
            )
            return

        # Check interval trigger (AUTO-01)
        if scheduler.is_due(config.reconcile_interval):
            # Map config scope to engine scope (AUTO-03)
            scope_map = {'all': 'all', '24h': 'recent', '7days': 'recent_7days'}
            engine_scope = scope_map.get(config.reconcile_scope, 'recent')
            log_info(f"Auto-reconciliation: interval trigger ({config.reconcile_interval}, scope: {config.reconcile_scope})")
            ReconciliationRunner(stash_interface, config, data_dir, queue_manager).run(
                scope=engine_scope, is_startup=False
            )
            return

    except Exception as e:
        log_warn(f"Auto-reconciliation check failed: {e}")


def handle_outage_summary():
    """Display outage history and metrics (MTTR, MTBF, availability)."""
    try:
        data_dir = get_plugin_data_dir()

        from worker.outage_history import (
            OutageHistory,
            calculate_outage_metrics,
            format_duration,
            format_elapsed_since
        )

        history = OutageHistory(data_dir)
        records = history.get_history()

        if not records:
            log_info("No outages recorded")
            return

        # Calculate metrics
        metrics = calculate_outage_metrics(records)

        log_info("=== Outage Summary Report ===")
        log_info(f"Total outages tracked: {len(records)}")
        log_info(f"Completed outages: {metrics['outage_count']}")
        log_info(f"Total downtime: {format_duration(metrics['total_downtime'])}")

        if metrics['outage_count'] > 0:
            log_info(f"MTTR (Mean Time To Repair): {format_duration(metrics['mttr'])}")

        if metrics['mtbf'] > 0:
            log_info(f"MTBF (Mean Time Between Failures): {format_duration(metrics['mtbf'])}")
            log_info(f"Availability: {metrics['availability']:.2f}%")

        # Check for ongoing outage
        current = history.get_current_outage()
        if current:
            log_info(f"ONGOING: started {format_elapsed_since(current.started_at)}")

        # Show last 10 outages
        log_info("=== Recent Outages ===")
        recent = records[-10:]
        recent.reverse()

        for idx, record in enumerate(recent, 1):
            import datetime
            start_dt = datetime.datetime.fromtimestamp(record.started_at)
            start_str = start_dt.strftime('%Y-%m-%d %H:%M:%S')

            if record.ended_at is None:
                duration_str = "ONGOING"
            else:
                duration_str = format_duration(record.duration)

            jobs_str = f", jobs_affected={record.jobs_affected}" if record.jobs_affected > 0 else ""
            log_info(f"{idx}. {start_str} - {duration_str}{jobs_str}")

        log_info("=== End Report ===")

    except Exception as e:
        log_error(f"Failed to generate outage summary: {e}")
        import traceback
        traceback.print_exc()


def handle_recover_outage_jobs():
    """Re-queue DLQ jobs that failed during last Plex outage (PlexServerDown only)."""
    try:
        data_dir = get_plugin_data_dir()

        from worker.outage_history import (
            OutageHistory,
            format_duration,
            format_elapsed_since
        )
        from sync_queue.dlq_recovery import (
            get_outage_dlq_entries,
            recover_outage_jobs,
            get_error_types_for_recovery
        )
        from sync_queue.dlq import DeadLetterQueue

        # Load outage history
        history = OutageHistory(data_dir)
        records = history.get_history()

        if not records:
            log_info("No outage history found - nothing to recover")
            return

        # Filter to completed outages only (ended_at is not None)
        completed = [r for r in records if r.ended_at is not None]

        if not completed:
            log_info("No completed outages found - recovery requires a resolved outage")
            return

        # Get last completed outage
        last_outage = completed[-1]

        log_info(f"Recovering DLQ jobs from outage: {format_duration(last_outage.duration)} (ended {format_elapsed_since(last_outage.ended_at)})")

        # Conservative default: PlexServerDown only
        error_types = get_error_types_for_recovery(include_optional=False)
        log_info(f"Recovery filter: {', '.join(error_types)}")

        # Query DLQ for entries in outage window
        dlq = DeadLetterQueue(data_dir)
        entries = get_outage_dlq_entries(
            dlq,
            last_outage.started_at,
            last_outage.ended_at,
            error_types
        )

        if not entries:
            log_info("No recoverable DLQ entries found for last outage window")
            return

        log_info(f"Found {len(entries)} DLQ entries to evaluate")

        # Get queue for re-enqueuing
        if not queue_manager:
            log_error("Queue manager not initialized")
            return

        queue = queue_manager.get_queue()
        if queue is None:
            log_error("Queue not available")
            return

        # Create PlexClient instance (same pattern as handle_health_check)
        if not config:
            log_error("No config available for Plex client")
            return

        from plex.client import PlexClient

        plex_client = PlexClient(
            url=config.plex_url,
            token=config.plex_token,
            connect_timeout=5.0,
            read_timeout=30.0
        )

        # Recover jobs
        result = recover_outage_jobs(
            entries,
            queue,
            stash_interface,
            plex_client,
            data_dir
        )

        # Log detailed results
        log_info(
            f"Recovery complete: {result.recovered} recovered, "
            f"{result.skipped_already_queued} already queued, "
            f"{result.skipped_plex_down} skipped (Plex down), "
            f"{result.skipped_scene_missing} skipped (scene missing), "
            f"{result.failed} failed"
        )

        if result.recovered > 0:
            log_info(f"Re-queued scene IDs: {result.recovered_scene_ids}")

    except Exception as e:
        log_error(f"Failed to recover outage jobs: {e}")
        import traceback
        traceback.print_exc()


def handle_health_check():
    """Check Plex server connectivity and circuit breaker status."""
    try:
        data_dir = get_plugin_data_dir()
        log_info("=== Plex Health Check ===")

        # Report circuit breaker state
        from worker.circuit_breaker import CircuitBreaker
        cb_file = os.path.join(data_dir, 'circuit_breaker.json')
        cb_status = CircuitBreaker.load_status(cb_file)
        log_info(f"Circuit Breaker State: {cb_status['state'].upper()}")
        if cb_status['is_open'] and cb_status['opened_at']:
            elapsed = time.time() - cb_status['opened_at']
            log_info(f"Circuit opened {int(elapsed / 60)}m {int(elapsed % 60)}s ago")

        # Test Plex connectivity with health probe
        if not config:
            log_error("No config available for health check")
            return

        from plex.client import PlexClient
        from plex.health import check_plex_health

        client = PlexClient(
            url=config.plex_url,
            token=config.plex_token,
            connect_timeout=5.0,
            read_timeout=5.0
        )

        is_healthy, latency_ms = check_plex_health(client, timeout=5.0)

        if is_healthy:
            log_info(f"Plex is HEALTHY (responded in {latency_ms:.0f}ms)")
        else:
            log_warn("Plex is UNREACHABLE")
            log_info("Verify Plex URL and network connectivity")

        # Report queue size
        if queue_manager:
            pending = queue_manager.get_queue().size
            if pending > 0:
                log_info(f"Queue: {pending} pending items")

                if cb_status['is_open']:
                    log_warn(f"{pending} jobs waiting for Plex to recover")
            else:
                log_info("Queue: empty")

        log_info("=== Health Check Complete ===")

    except Exception as e:
        log_error(f"Health check failed: {e}")
        import traceback
        traceback.print_exc()


# Dispatch table for management modes (no Stash connection needed)
_MANAGEMENT_HANDLERS = {
    'queue_status': lambda args: handle_queue_status(),
    'clear_queue': lambda args: handle_clear_queue(),
    'clear_match_cache': lambda args: handle_clear_match_cache(),
    'clear_dlq': lambda args: handle_clear_dlq(),
    'purge_dlq': lambda args: handle_purge_dlq(args.get('days', 30)),
    'process_queue': lambda args: handle_process_queue(),
    'reconcile_all': lambda args: handle_reconcile('all'),
    'reconcile_recent': lambda args: handle_reconcile('recent'),
    'reconcile_missing_metadata': lambda args: handle_reconcile('missing_metadata'),
    'reconcile_7days': lambda args: handle_reconcile('recent_7days'),
    'health_check': lambda args: handle_health_check(),
    'outage_summary': lambda args: handle_outage_summary(),
    'recover_outage_jobs': lambda args: handle_recover_outage_jobs(),
}


def handle_task(task_args: dict, stash=None):
    """Handle manual task trigger from Stash UI.

    Args:
        task_args: Task arguments (mode determines operation)
        stash: StashInterface for API calls (required for sync modes)
    """
    mode = task_args.get('mode', 'recent')
    log_info(f"Task starting with mode: {mode}")

    handler = _MANAGEMENT_HANDLERS.get(mode)
    if handler:
        handler(task_args)
        return

    # Sync tasks require Stash connection
    handle_bulk_sync(mode, stash)


def handle_bulk_sync(mode: str, stash):
    """Batch-query scenes from Stash and enqueue them for Plex sync.

    Args:
        mode: 'all' for every scene, 'recent' for last 24 hours.
        stash: StashInterface for GQL queries.
    """
    from validation.scene_extractor import extract_scene_metadata, get_scene_file_path

    if not stash:
        log_error("No Stash connection available")
        return

    try:
        scenes = _fetch_scenes_for_sync(mode, stash)
        if not scenes:
            log_info("No scenes found to sync")
            return

        log_info(f"Found {len(scenes)} scenes to sync")

        data_dir = get_plugin_data_dir()
        current_timestamps = load_sync_timestamps(data_dir)
        queued = 0
        skipped = 0
        already_synced = 0
        already_queued = 0

        for scene in scenes:
            scene_id = scene.get('id')
            if not scene_id:
                continue

            file_path = get_scene_file_path(scene)
            if not file_path:
                skipped += 1
                continue

            if _is_already_synced(scene, int(scene_id), current_timestamps):
                already_synced += 1
                continue

            job_data = extract_scene_metadata(scene)
            job_data['path'] = file_path

            result = queue_manager.try_enqueue(int(scene_id), "metadata", job_data)
            if result.enqueued:
                queued += 1
            else:
                already_queued += 1

        parts = [f"Queued {queued} scenes for sync"]
        if already_synced:
            parts.append(f"{already_synced} already synced")
        if already_queued:
            parts.append(f"{already_queued} already in queue")
        if skipped:
            parts.append(f"{skipped} without files")
        log_info(parts[0] + (" (" + ", ".join(parts[1:]) + ")" if len(parts) > 1 else ""))

    except Exception as e:
        log_error(f"Task error: {e}")
        import traceback
        traceback.print_exc()


# Batch query fragment for bulk sync — all needed fields in one call
_BATCH_FRAGMENT = """
    id
    title
    details
    date
    rating100
    updated_at
    files { path }
    studio { name }
    performers { name }
    tags { name }
    paths { screenshot preview }
"""


def _fetch_scenes_for_sync(mode: str, stash) -> list:
    """Fetch scenes from Stash based on sync mode."""
    if mode == 'all':
        log_info("Fetching all scenes...")
        return stash.find_scenes(fragment=_BATCH_FRAGMENT) or []

    import datetime
    yesterday = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
    log_info(f"Fetching scenes updated since {yesterday}...")
    return stash.find_scenes(
        f={"updated_at": {"value": yesterday, "modifier": "GREATER_THAN"}},
        fragment=_BATCH_FRAGMENT
    ) or []


def _is_already_synced(scene: dict, scene_id: int, timestamps: dict) -> bool:
    """Check if a scene was already synced since its last update."""
    scene_updated_at = scene.get('updated_at')
    if not scene_updated_at or not timestamps:
        return False
    last_synced = timestamps.get(scene_id)
    if not last_synced:
        return False
    try:
        from datetime import datetime
        dt = datetime.fromisoformat(scene_updated_at.replace('Z', '+00:00'))
        return dt.timestamp() <= last_synced
    except (ValueError, AttributeError):
        return False


def is_scan_job_running(stash) -> bool:
    """Check if a scan/generate job is running in Stash.

    Delegates to hooks.handlers.is_scan_running to avoid duplication.
    """
    from hooks.handlers import is_scan_running
    return is_scan_running(stash)


def main():
    """Main entry point for Stash plugin."""
    # Read input from stdin (Stash plugin protocol)
    try:
        raw_input = sys.stdin.read()
        input_data = json.loads(raw_input)
    except json.JSONDecodeError as e:
        log_error(f"JSON decode error: {e}")
        print(json.dumps({"error": f"Invalid JSON input: {e}"}))
        sys.exit(1)

    # Check args first - for hooks, check if scan is running before heavy init
    args = input_data.get("args", {})
    is_hook = "hookContext" in args

    # temp_stash holds the pre-created StashInterface for hook invocations so it
    # can be reused by extract_config_from_input() rather than opening a second
    # connection to Stash. This avoids duplicate GQL calls (version + apiKey) that
    # add CPU/goroutine load on Stash while it may be handling concurrent outbound
    # HTTPS connections (e.g. stashdb.org scraping), which can cause TLS timeout.
    temp_stash = None

    # Hooks must be near-zero overhead unless this is the explicit
    # identification-complete event (Scene.Update.Post with stash_ids).
    # Any other hook exits immediately before init/network work.
    if is_hook:
        hook_context = args.get("hookContext", {})
        hook_type = hook_context.get("type", "")
        hook_input = hook_context.get("input") or {}
        is_identification = hook_type == "Scene.Update.Post" and 'stash_ids' in hook_input

        if not is_identification:
            print(json.dumps({"output": "ok"}))
            return

        # Identification event: create stash interface for downstream work.
        temp_stash = get_stash_interface(input_data)

    # Initialize on first call
    global queue_manager, config
    if queue_manager is None:
        # Pass temp_stash (if created above) to reuse the existing connection and
        # avoid creating a second StashInterface with its own 2 GQL calls to Stash.
        config_dict = extract_config_from_input(input_data, existing_stash=temp_stash)
        init_success = initialize(config_dict, resume_orphaned=not is_hook, start_worker=not is_hook)
        if not init_success:
            # Initialization failed (config validation error)
            # Lock was never acquired or was released, safe to exit
            print(json.dumps({"error": "Configuration validation failed"}))
            return

    # Check if plugin is disabled (config may have loaded but plugin disabled)
    if config and not config.enabled:
        print(json.dumps({"output": "disabled"}))
        return

    # Recovery detection and auto-reconciliation only run for tasks, not hooks.
    # Hooks must return fast (<100ms target) because Stash blocks the save until
    # the plugin process exits. Running these on every hook invocation added
    # unnecessary latency to every scene save.
    if not is_hook:
        maybe_check_recovery()
        maybe_auto_reconcile()

    # Handle hook or task
    if is_hook:
        try:
            handle_hook(args["hookContext"], stash=stash_interface, server_connection=input_data.get('server_connection', {}))
        except Exception as e:
            log_error(f"handle_hook exception: {e}")
            import traceback
            traceback.print_exc()
    elif "mode" in args:
        try:
            handle_task(args, stash=stash_interface)
        except Exception as e:
            log_error(f"handle_task exception: {e}")
            import traceback
            traceback.print_exc()

    # Give worker time to process pending jobs before exiting
    # Worker thread is daemon, so it dies when main process exits
    # Skip for hooks — Stash blocks the save until the plugin exits, so waiting
    # here adds latency to every scene save. The worker will drain on the next
    # task invocation or via 'Process Queue'.
    # Skip for management tasks that don't enqueue work
    # Skip if worker lock was not acquired (another process is draining)
    management_modes = {'clear_queue', 'clear_dlq', 'purge_dlq', 'queue_status', 'process_queue', 'reconcile_all', 'reconcile_recent', 'reconcile_missing_metadata', 'reconcile_7days', 'health_check', 'outage_summary', 'recover_outage_jobs'}
    task_mode = args.get("mode", "") if not is_hook else ""
    if is_hook:
        # Hooks: return immediately after enqueue. Worker drain happens on tasks.
        pass
    elif worker and queue_manager and task_mode not in management_modes and worker._lock_fd is not None:
        import time
        from worker.stats import SyncStats
        from sync_queue.operations import get_stats as get_queue_stats
        queue = queue_manager.get_queue()
        data_dir = get_plugin_data_dir()
        queue_path = os.path.join(data_dir, 'queue')

        # Load stats for dynamic timeout calculation
        stats_path = os.path.join(data_dir, 'stats.json')
        stats = SyncStats.load_from_file(stats_path)

        # Dynamic timeout based on measured processing time.
        # Use pending + in_progress as initial count so we don't exit early when
        # the worker has already dequeued (moved to in_progress) the only pending item.
        try:
            queue_counts = get_queue_stats(queue_path)
            initial_size = queue_counts['pending'] + queue_counts['in_progress']
        except Exception:
            initial_size = queue.size  # Fallback to pending-only count
        max_wait = stats.get_estimated_timeout(initial_size)
        wait_interval = 0.5
        waited = 0
        last_size = initial_size

        # Determine time_per_item for messaging
        time_per_item = stats.avg_processing_time if stats.jobs_processed >= 5 else stats.DEFAULT_TIME_PER_ITEM

        if initial_size > 0:
            if stats.jobs_processed >= 5:
                log_info(f"Processing {initial_size} queued item(s), timeout {max_wait:.0f}s (based on {stats.avg_processing_time:.2f}s/item avg)")
            else:
                log_info(f"Processing {initial_size} queued item(s), timeout {max_wait:.0f}s (using default estimate)")

        while waited < max_wait:
            try:
                # Check both pending AND in_progress: if a job was dequeued (in_progress)
                # but not yet acked, queue.size returns 0 but the job is still being processed.
                try:
                    counts = get_queue_stats(queue_path)
                    size = counts['pending'] + counts['in_progress']
                except Exception:
                    size = queue.size  # Fallback
                if size == 0:
                    break
                # Log progress every 10 items processed
                if last_size - size >= 10:
                    log_info(f"Progress: {initial_size - size}/{initial_size} processed, {size} remaining")
                    last_size = size
                time.sleep(wait_interval)
                waited += wait_interval
            except Exception as e:
                log_error(f"Error checking queue: {e}")
                break

        if waited >= max_wait:
            try:
                counts = get_queue_stats(queue_path)
                remaining = counts['pending'] + counts['in_progress']
            except Exception:
                remaining = queue.size
            if remaining > 0:
                estimated_remaining_time = remaining * time_per_item
                log_warn(
                    f"Timeout after {max_wait:.0f}s with {remaining} items remaining "
                    f"(est. {estimated_remaining_time:.0f}s more needed). "
                    f"Run 'Process Queue' task to continue without timeout limits."
                )

    # Graceful shutdown: stop worker so in-flight items are acked/nacked
    # (prevents auto_resume from re-processing them in next invocation)
    shutdown()

    # Return empty response (success)
    print(json.dumps({"output": "ok"}))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        shutdown()
        sys.exit(0)
    except Exception as e:
        import traceback
        print(json.dumps({"error": str(e)}))
        traceback.print_exc()
        shutdown()
        sys.exit(1)
