"""
Background worker for processing sync jobs.

Implements reliable job processing with acknowledgment workflow:
- Acknowledges successful jobs
- Retries transient failures with exponential backoff
- Moves permanently failed jobs to DLQ
- Circuit breaker pauses processing during Plex outages
"""

import os
import time
import threading
from typing import Optional, TYPE_CHECKING

from worker.stats import SyncStats

# Lazy imports to avoid circular import with validation module
# These are imported inside _update_metadata() where they're used

from shared.log import create_logger
log_trace, log_debug, log_info, log_warn, log_error = create_logger("Worker")

# Lazy imports to avoid module-level pollution in tests
# These functions are imported inside methods that use them
# to ensure imports are fresh and not polluted by test mocking

if TYPE_CHECKING:
    from validation.config import Stash2PlexConfig
    from plex.client import PlexClient
    from plex.cache import PlexCache, MatchCache


class TransientError(Exception):
    """Retry-able errors (network, timeout, 5xx)"""
    pass


class PermanentError(Exception):
    """Non-retry-able errors (4xx except 429, validation)"""
    pass


class SyncWorker:
    """
    Background worker that processes sync jobs from the queue.

    Runs in a daemon thread and processes jobs with proper acknowledgment:
    - Success: ack_job
    - Transient failure: exponential backoff retry with metadata in job
    - Permanent failure or max retries: fail_job + DLQ
    - Circuit breaker: pauses processing after consecutive failures
    """

    def __init__(
        self,
        queue_manager: 'QueueManager',
        dlq: 'DeadLetterQueue',
        config: 'Stash2PlexConfig',
        data_dir: Optional[str] = None,
        max_retries: int = 5,
    ):
        """
        Initialize sync worker.

        Args:
            queue_manager: QueueManager instance (owns queue + dedup)
            dlq: DeadLetterQueue for permanently failed jobs
            config: Stash2PlexConfig with Plex URL, token, and timeouts
            data_dir: Plugin data directory for sync timestamp updates
            max_retries: Maximum retry attempts before moving to DLQ (default for standard errors)
        """
        self.queue_manager = queue_manager
        self.dlq = dlq
        self.config = config
        self.data_dir = data_dir
        self.max_retries = max_retries
        self.running = False
        self.thread: Optional[threading.Thread] = None
        self._plex_client: Optional['PlexClient'] = None

        # Initialize caches (lazy, created on first use)
        self._library_cache: Optional['PlexCache'] = None
        self._match_cache: Optional['MatchCache'] = None

        # Initialize stats tracking
        self._stats = SyncStats()
        if data_dir is not None:
            stats_path = os.path.join(data_dir, 'stats.json')
            self._stats = SyncStats.load_from_file(stats_path)

        # DLQ status logging interval
        self._jobs_since_dlq_log = 0
        self._dlq_log_interval = 10  # Log DLQ status every 10 jobs

        # Outage history tracking
        if data_dir is not None:
            from worker.outage_history import OutageHistory
            self._outage_history = OutageHistory(data_dir)
        else:
            self._outage_history = None

        # Circuit breaker for resilience during Plex outages
        from worker.circuit_breaker import CircuitBreaker

        # Enable state persistence when data_dir is available
        cb_state_file = None
        if data_dir is not None:
            cb_state_file = os.path.join(data_dir, 'circuit_breaker.json')

        self.circuit_breaker = CircuitBreaker(
            failure_threshold=5,
            recovery_timeout=60.0,
            success_threshold=1,
            state_file=cb_state_file,
            outage_history=self._outage_history
        )

        # Worker exclusion lock file descriptor (set by try_start_exclusive)
        self._lock_fd = None

        # Health check state for active probes during OPEN circuit
        self._last_health_check: float = 0.0
        self._health_check_interval: float = 5.0  # Initial: 5s
        self._consecutive_health_failures: int = 0

        # Recovery rate limiter for graduated queue drain
        from worker.rate_limiter import RecoveryRateLimiter
        self._rate_limiter = RecoveryRateLimiter()
        self._was_in_recovery = False

        # Check if recovery period is active from prior session (cross-restart continuity)
        if data_dir is not None:
            from worker.recovery import RecoveryScheduler
            recovery_scheduler = RecoveryScheduler(data_dir, outage_history=self._outage_history)
            recovery_state = recovery_scheduler.load_state()
            if recovery_state.recovery_started_at > 0:
                # Recovery period was active before restart — resume from current position
                self._rate_limiter.start_recovery_period(now=recovery_state.recovery_started_at)
                self._was_in_recovery = True
                log_info("Resuming recovery rate limiting from prior session")

    def start(self):
        """Start the background worker thread"""
        if self.running:
            log_trace("Already running")
            return

        # Cleanup old DLQ entries
        retention_days = getattr(self.config, 'dlq_retention_days', 30)
        self.dlq.delete_older_than(days=retention_days)

        # Log DLQ status on startup
        self._log_dlq_status()

        self.running = True
        self.thread = threading.Thread(target=self._worker_loop, daemon=True)
        self.thread.start()
        log_info("Started")

    def try_start_exclusive(self, resume_orphaned: bool = True) -> bool:
        """
        Acquire the worker exclusion lock and start the background thread.

        Only one plugin process should drain the queue at a time. During bulk
        scans many hook processes fire concurrently; without this lock each
        starts its own worker thread, causing cascading Plex API timeouts.

        Args:
            resume_orphaned: If True, resume in-progress items left by a prior
                             crashed process before starting. Pass False for hook
                             invocations — an orphaned PlexNotFound item stuck in
                             library.all() would monopolise the 10-second hook
                             window and block all newer jobs.

        Returns:
            True  — lock acquired, worker started.
            False — lock held by another process; caller should enqueue only.
        """
        if self.data_dir is None:
            # No data_dir: can't create lock file, just start unconditionally
            self.start()
            return True

        lock_path = os.path.join(self.data_dir, 'worker.lock')
        try:
            import fcntl
            self._lock_fd = open(lock_path, 'w')
            fcntl.flock(self._lock_fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (BlockingIOError, OSError):
            # Lock held by another process — just enqueue, don't drain
            if self._lock_fd:
                self._lock_fd.close()
                self._lock_fd = None
            return False

        try:
            if resume_orphaned:
                from sync_queue.operations import resume_orphaned_items
                resumed = resume_orphaned_items(self.queue_manager.queue_path)
                if resumed == 0:
                    log_trace("No orphaned items to resume")
            else:
                log_trace("Skipping orphaned item resume (hook invocation)")
            self.start()
        except Exception as e:
            log_error(f"Failed to start worker: {e}")
            self._release_lock()
            return False

        return True

    def _release_lock(self):
        """Release the worker exclusion lock if held."""
        if self._lock_fd is None:
            return
        try:
            import fcntl
            fcntl.flock(self._lock_fd.fileno(), fcntl.LOCK_UN)
        except OSError:
            pass
        try:
            self._lock_fd.close()
        except OSError:
            pass
        self._lock_fd = None

    def _log_dlq_status(self):
        """Log DLQ status if jobs present."""
        count = self.dlq.get_count()
        if count > 0:
            log_warn(f"DLQ contains {count} failed jobs requiring review")
            recent = self.dlq.get_recent(limit=5)
            for entry in recent:
                log_debug(
                    f"DLQ #{entry['id']}: scene {entry['scene_id']} - "
                    f"{entry['error_type']}: {entry['error_message'][:80]}"
                )

    def _log_batch_summary(self):
        """Log periodic summary of sync operations with JSON stats."""
        import json

        stats = self._stats

        # Human-readable summary line
        log_info(
            f"Sync summary: {stats.jobs_succeeded}/{stats.jobs_processed} succeeded "
            f"({stats.success_rate:.1f}%), avg {stats.avg_processing_time*1000:.0f}ms, "
            f"confidence: {stats.high_confidence_matches} high / {stats.low_confidence_matches} low"
        )

        # JSON batch summary for machine parsing
        stats_dict = {
            "processed": stats.jobs_processed,
            "succeeded": stats.jobs_succeeded,
            "failed": stats.jobs_failed,
            "to_dlq": stats.jobs_to_dlq,
            "success_rate": f"{stats.success_rate:.1f}%",
            "avg_time_ms": int(stats.avg_processing_time * 1000),
            "high_confidence": stats.high_confidence_matches,
            "low_confidence": stats.low_confidence_matches,
            "errors_by_type": stats.errors_by_type,
        }
        log_info(f"Stats: {json.dumps(stats_dict)}")

        # DLQ summary if items present (using get_error_summary method)
        dlq_summary = self.dlq.get_error_summary()
        if dlq_summary:
            total = sum(dlq_summary.values())
            breakdown = ", ".join(f"{count} {err_type}" for err_type, count in dlq_summary.items())
            log_warn(f"DLQ contains {total} items: {breakdown}")

    def stop(self):
        """Stop the background worker thread and release the exclusion lock."""
        if not self.running:
            self._release_lock()
            return

        log_trace("Stopping worker...")
        self.running = False

        if self.thread:
            # Give current job time to finish (get timeout=2s + processing)
            self.thread.join(timeout=10)
            if self.thread.is_alive():
                log_warn("Worker thread did not stop within 10s — current job may be reprocessed")

        self._release_lock()
        log_trace("Worker stopped")

    def _prepare_for_retry(self, job: dict, error: Exception) -> dict:
        """
        Add retry metadata to job before re-enqueueing.

        Stores retry_count, next_retry_at, and last_error_type in job dict
        so retry state survives worker restart (crash-safe).

        Args:
            job: Job dict to update
            error: The exception that caused the retry

        Returns:
            Updated job dict with retry metadata
        """
        from worker.backoff import calculate_delay, get_retry_params

        base, cap, max_retries = get_retry_params(error)
        retry_count = job.get('retry_count', 0) + 1
        delay = calculate_delay(retry_count - 1, base, cap)  # -1 because we just incremented

        job['retry_count'] = retry_count
        job['next_retry_at'] = time.time() + delay
        job['last_error_type'] = type(error).__name__
        return job

    def _is_ready_for_retry(self, job: dict) -> bool:
        """
        Check if job's backoff delay has elapsed.

        Args:
            job: Job dict with optional next_retry_at field

        Returns:
            True if job is ready for processing (no delay or delay elapsed)
        """
        next_retry_at = job.get('next_retry_at', 0)
        return time.time() >= next_retry_at

    def _get_max_retries_for_error(self, error: Exception) -> int:
        """
        Get max retries based on error type.

        PlexNotFound errors get more retries (12) to allow for library scanning.
        Other transient errors use the standard max_retries (5).

        Args:
            error: The exception that triggered the retry

        Returns:
            Maximum number of retries for this error type
        """
        from worker.backoff import get_retry_params
        _, _, max_retries = get_retry_params(error)
        return max_retries

    def _requeue_with_metadata(self, job: dict):
        """
        Re-enqueue job with updated retry metadata.

        persist-queue's nack() doesn't support modifying job data,
        so we ack the current job and enqueue a fresh copy with
        updated metadata. Bypasses dedup — the scene is still in flight.

        Args:
            job: Job dict with retry metadata already added
        """
        from sync_queue.operations import _job_counter

        scene_id = job.get('scene_id')
        new_job = {
            'job_id': next(_job_counter),
            'scene_id': scene_id,
            'update_type': job.get('update_type'),
            'data': job.get('data', {}),
            'enqueued_at': job.get('enqueued_at', time.time()),
            'job_key': job.get('job_key', f"scene_{scene_id}"),
            'retry_count': job.get('retry_count', 0),
            'next_retry_at': job.get('next_retry_at', 0),
            'last_error_type': job.get('last_error_type'),
        }
        self.queue_manager.reenqueue(job, new_job)

    def _handle_job(self, item: dict, recently_synced: set, sync_timestamps: dict) -> str:
        """
        Process one dequeued job through the full ack/retry/DLQ pipeline.

        Handles in-session and cross-session dedup, all error branches, and
        updates recently_synced on success. Both _worker_loop and run_batch
        call this so retry/DLQ logic lives in exactly one place.

        Args:
            item: Dequeued job dict (already passed backoff check by caller)
            recently_synced: Mutable set of scene_ids synced this session/batch
            sync_timestamps: Cross-session sync timestamps for stale-entry dedup

        Returns:
            'success'    — job processed, caller should apply inter-job delay
            'skipped'    — dedup hit, acked without processing
            'retrying'   — requeued with backoff
            'failed'     — moved to DLQ
            'server_down' — Plex unreachable, nacked; caller should break/pause
        """
        from worker.circuit_breaker import CircuitState
        from plex.exceptions import PlexServerDown, PlexNotFound

        scene_id = item.get('scene_id')
        jid = item.get('job_id') or scene_id
        retry_count = item.get('retry_count', 0)

        # In-session dedup: skip scenes already synced this run
        if scene_id is not None and scene_id in recently_synced:
            self.queue_manager.ack(item)
            log_debug(f"Job {jid} skipped — scene {scene_id} already synced this session")
            return 'skipped'

        # Cross-session dedup: skip stale queue entries from before the last sync
        if scene_id is not None and sync_timestamps:
            enqueued_at = item.get('enqueued_at', 0)
            last_synced = sync_timestamps.get(int(scene_id))
            if last_synced and enqueued_at <= last_synced and retry_count == 0:
                self.queue_manager.ack(item)
                log_debug(f"Job {jid} skipped — scene {scene_id} already synced "
                          f"(enqueued {enqueued_at:.0f} <= synced {last_synced:.0f})")
                return 'skipped'

        log_debug(f"Processing job {jid} for scene {scene_id} (attempt {retry_count + 1})")
        _job_start = time.perf_counter()

        try:
            confidence = self._process_job(item)
            _job_elapsed = time.perf_counter() - _job_start
            self._stats.record_success(_job_elapsed, confidence=confidence or 'high')

            previous_state = self.circuit_breaker.state
            self.queue_manager.ack(item)
            self.circuit_breaker.record_success()
            self._rate_limiter.record_result(success=True)

            # Detect HALF_OPEN -> CLOSED transition and start graduated recovery drain
            if previous_state == CircuitState.HALF_OPEN and self.circuit_breaker.state == CircuitState.CLOSED:
                self._rate_limiter.start_recovery_period()
                self._was_in_recovery = True
                if self.data_dir is not None:
                    from worker.recovery import RecoveryScheduler
                    scheduler = RecoveryScheduler(self.data_dir, outage_history=self._outage_history)
                    state = scheduler.load_state()
                    state.recovery_started_at = time.time()
                    scheduler.save_state(state)
                log_info("Recovery period started: graduated rate limiting enabled")

            log_info(f"Job {jid} completed")
            if scene_id is not None:
                recently_synced.add(scene_id)

            # Periodic stats/cache summary
            self._jobs_since_dlq_log += 1
            if self._jobs_since_dlq_log >= self._dlq_log_interval:
                self._log_batch_summary()
                self._log_cache_stats()
                self._jobs_since_dlq_log = 0
                if self.data_dir is not None:
                    stats_path = os.path.join(self.data_dir, 'stats.json')
                    self._stats.save_to_file(stats_path)

            return 'success'

        except PlexServerDown:
            self.queue_manager.nack(item)
            self.circuit_breaker.record_failure()
            self._rate_limiter.record_result(success=False)
            if self.circuit_breaker.state == CircuitState.OPEN:
                pending = self.queue_manager.get_queue().size
                log_warn(f"Plex server is down — pausing, {pending} job(s) waiting")
            return 'server_down'

        except PlexNotFound as e:
            _job_elapsed = time.perf_counter() - _job_start
            if self.config and getattr(self.config, 'skip_not_found', False):
                self.queue_manager.ack(item)
                log_info(f"Job {jid} skipped — scene {scene_id} not in Plex (skip_not_found enabled)")
                self._stats.record_failure(type(e).__name__, _job_elapsed, to_dlq=False)
                return 'skipped'
            job = self._prepare_for_retry(item, e)
            max_retries = self._get_max_retries_for_error(e)
            job_retry_count = job.get('retry_count', 0)
            if job_retry_count >= max_retries:
                log_warn(f"Job {jid} exceeded max retries ({max_retries}), moving to DLQ")
                self.queue_manager.fail(item)
                self.dlq.add(job, e, job_retry_count)
                self._stats.record_failure(type(e).__name__, _job_elapsed, to_dlq=True)
                return 'failed'
            delay = job.get('next_retry_at', 0) - time.time()
            log_debug(f"Job {jid} not in Plex yet (attempt {job_retry_count}/{max_retries}), retry in {delay:.1f}s")
            self._requeue_with_metadata(job)
            self._stats.record_failure(type(e).__name__, _job_elapsed, to_dlq=False)
            return 'retrying'

        except TransientError as e:
            _job_elapsed = time.perf_counter() - _job_start
            self.circuit_breaker.record_failure()
            self._rate_limiter.record_result(success=False)
            if self.circuit_breaker.state == CircuitState.OPEN:
                log_warn(f"Circuit breaker OPENED after {type(e).__name__}: {e}")
            job = self._prepare_for_retry(item, e)
            max_retries = self._get_max_retries_for_error(e)
            job_retry_count = job.get('retry_count', 0)
            if job_retry_count >= max_retries:
                log_warn(f"Job {jid} exceeded max retries ({max_retries}), moving to DLQ")
                self.queue_manager.fail(item)
                self.dlq.add(job, e, job_retry_count)
                self._stats.record_failure(type(e).__name__, _job_elapsed, to_dlq=True)
                return 'failed'
            delay = job.get('next_retry_at', 0) - time.time()
            log_debug(f"Job {jid} failed (attempt {job_retry_count}/{max_retries}), retry in {delay:.1f}s: {e}")
            self._requeue_with_metadata(job)
            self._stats.record_failure(type(e).__name__, _job_elapsed, to_dlq=False)
            return 'retrying'

        except PermanentError as e:
            _job_elapsed = time.perf_counter() - _job_start
            log_error(f"Job {jid} permanent failure, moving to DLQ: {e}")
            self.queue_manager.fail(item)
            self.dlq.add(item, e, item.get('retry_count', 0))
            self._stats.record_failure(type(e).__name__, _job_elapsed, to_dlq=True)
            return 'failed'

        except Exception as e:
            _job_elapsed = time.perf_counter() - _job_start
            self.circuit_breaker.record_failure()
            self._rate_limiter.record_result(success=False)
            job = self._prepare_for_retry(item, e)
            max_retries = self.max_retries
            job_retry_count = job.get('retry_count', 0)
            if job_retry_count >= max_retries:
                log_warn(f"Job {jid} unexpected error exceeded max retries ({max_retries}), moving to DLQ: {e}")
                self.queue_manager.fail(item)
                self.dlq.add(job, e, job_retry_count)
                self._stats.record_failure(type(e).__name__, _job_elapsed, to_dlq=True)
                return 'failed'
            delay = job.get('next_retry_at', 0) - time.time()
            log_warn(f"Job {jid} unexpected error (attempt {job_retry_count}/{max_retries}), retry in {delay:.1f}s: {e}")
            self._requeue_with_metadata(job)
            self._stats.record_failure(type(e).__name__, _job_elapsed, to_dlq=False)
            return 'retrying'

    def _worker_loop(self):
        """Main worker loop - runs in background thread"""

        _recently_synced: set = set()

        # Load sync timestamps for cross-session dedup.
        # If a scene was already synced (timestamp exists and no newer update),
        # skip it — prevents the same scene from being reprocessed every plugin
        # invocation due to auto_resume or stale queue entries.
        _sync_timestamps: dict = {}
        if self.data_dir is not None:
            from sync_queue.operations import load_sync_timestamps as _load_ts
            _sync_timestamps = _load_ts(self.data_dir)

        # Track consecutive not-ready nacks to detect when ALL items are waiting
        # for backoff. Without this, the worker spins dequeuing and nacking
        # thousands of not-ready items per second (the "queue balloon" bug).
        _consecutive_not_ready = 0
        _earliest_retry_at = float('inf')

        while self.running:
            try:
                _dbg = getattr(self.config, 'debug_logging', False)

                # Check circuit breaker first - pause if Plex is down
                if not self.circuit_breaker.can_execute():
                    if _dbg:
                        log_info(f"[DEBUG] Circuit breaker state={self.circuit_breaker.state.value}, sleeping {self.config.poll_interval}s")

                    # Active health check during OPEN state to detect recovery
                    now = time.time()
                    if now - self._last_health_check >= self._health_check_interval:
                        from plex.health import check_plex_health

                        client = self._get_plex_client()
                        is_healthy, latency_ms = check_plex_health(client, timeout=5.0)
                        self._last_health_check = now

                        if is_healthy:
                            # Plex is back online
                            log_info(f"Plex health check passed ({latency_ms:.0f}ms), recovery possible")
                            self._consecutive_health_failures = 0
                            self._health_check_interval = 5.0
                            # NOTE: Do NOT directly modify circuit breaker state here.
                            # Circuit breaker's own recovery_timeout handles OPEN->HALF_OPEN transition.
                            # This health check is informational - the next can_execute() call will
                            # naturally transition to HALF_OPEN if timeout has elapsed.
                        else:
                            # Plex still down, apply backoff
                            self._consecutive_health_failures += 1
                            from worker.backoff import calculate_delay
                            self._health_check_interval = calculate_delay(
                                retry_count=self._consecutive_health_failures,
                                base=5.0,
                                cap=60.0,
                                jitter_seed=None  # Random jitter in production
                            )
                            log_debug(f"Plex health check failed (attempt #{self._consecutive_health_failures}), next check in {self._health_check_interval:.1f}s")

                    # Sleep in small increments so stop() can interrupt quickly
                    for _ in range(int(self.config.poll_interval * 2)):
                        if not self.running:
                            return
                        time.sleep(0.5)
                    continue

                # Rate limit during recovery period (graduated queue drain)
                wait_time = self._rate_limiter.should_wait()
                if wait_time > 0:
                    if _dbg:
                        log_info(f"[DEBUG] Recovery rate limit: waiting {wait_time:.2f}s (rate={self._rate_limiter.current_rate():.1f}/s)")
                    # Sleep in small chunks so stop() can interrupt quickly
                    remaining = wait_time
                    while remaining > 0 and self.running:
                        chunk = min(remaining, 0.5)
                        time.sleep(chunk)
                        remaining -= chunk
                    continue

                # Check if recovery period ended (ramp complete)
                if not self._rate_limiter.is_in_recovery_period() and self._was_in_recovery:
                    self._was_in_recovery = False
                    if self.data_dir is not None:
                        from worker.recovery import RecoveryScheduler
                        scheduler = RecoveryScheduler(self.data_dir, outage_history=self._outage_history)
                        scheduler.clear_recovery_period()
                    log_info("Recovery period complete: normal processing speed resumed")

                # Get next pending job (2 second timeout — short so stop() isn't blocked)
                item = self.queue_manager.get_pending(timeout=2)
                if item is None:
                    if _dbg:
                        log_info("[DEBUG] Queue poll: timeout, no items")
                    continue

                # Check if backoff delay has elapsed
                if not self._is_ready_for_retry(item):
                    next_retry = item.get('next_retry_at', 0)
                    _earliest_retry_at = min(_earliest_retry_at, next_retry)
                    _consecutive_not_ready += 1

                    if _dbg:
                        remaining = next_retry - time.time()
                        _dbg_id = item.get('job_id') or item.get('scene_id')
                        log_info(f"[DEBUG] Job {_dbg_id} backoff not elapsed ({remaining:.1f}s remaining), streak={_consecutive_not_ready}")

                    self.queue_manager.nack(item)

                    # If we've cycled through many not-ready items without finding
                    # a ready one, all items are waiting for backoff. Sleep until
                    # the earliest retry time instead of spinning.
                    # Threshold: after 50 consecutive not-ready nacks (or queue.size,
                    # whichever is larger), assume everything is waiting.
                    queue_size = max(self.queue_manager.get_queue().size, 50)
                    if _consecutive_not_ready >= queue_size:
                        sleep_until = _earliest_retry_at - time.time()
                        # Clamp to [1, 30] seconds — don't sleep too long (stop() responsiveness)
                        # and don't sleep too short (avoid hot loop)
                        sleep_secs = max(1.0, min(30.0, sleep_until))
                        if _dbg:
                            log_info(f"[DEBUG] All {_consecutive_not_ready} items waiting for backoff, sleeping {sleep_secs:.1f}s")
                        else:
                            log_debug(f"All {_consecutive_not_ready} items waiting for backoff, sleeping {sleep_secs:.1f}s")
                        # Sleep in small chunks so stop() can interrupt
                        remaining_sleep = sleep_secs
                        while remaining_sleep > 0 and self.running:
                            chunk = min(remaining_sleep, 0.5)
                            time.sleep(chunk)
                            remaining_sleep -= chunk
                        # Reset counters for next cycle
                        _consecutive_not_ready = 0
                        _earliest_retry_at = float('inf')
                    else:
                        time.sleep(0.1)  # Small delay between individual nacks
                    continue

                # Item is ready — reset not-ready streak
                _consecutive_not_ready = 0
                _earliest_retry_at = float('inf')

                outcome = self._handle_job(item, _recently_synced, _sync_timestamps)
                if outcome == 'success':
                    time.sleep(0.15)  # Brief pause between jobs to avoid overwhelming Plex

            except Exception as e:
                # Worker loop error: log and continue
                log_error(f"Worker loop error: {e}")
                time.sleep(1)  # Avoid tight loop on persistent errors

    def run_batch(
        self,
        progress_callback=None,
        job_delay_secs: float = 0.15,
    ) -> dict:
        """
        Process all pending jobs synchronously, returning when the queue is empty.

        Shares all job-handling logic with the background worker loop via
        _handle_job — retry routing, DLQ, dedup, and cross-session timestamp
        checks are identical in both paths.

        Args:
            progress_callback: Optional callable(float) receiving progress 0-100.
                               Called after every 5 jobs or every 10 seconds.
            job_delay_secs: Inter-job pause in seconds (default 0.15). Keeps
                            Plex from being overwhelmed during large batches.

        Returns:
            Dict with keys 'processed', 'failed', 'skipped'.
        """
        from sync_queue.operations import get_stats

        recently_synced: set = set()
        sync_timestamps: dict = {}
        if self.data_dir is not None:
            from sync_queue.operations import load_sync_timestamps as _load_ts
            sync_timestamps = _load_ts(self.data_dir)

        queue_path = os.path.join(self.data_dir, 'queue') if self.data_dir else None
        total = 0
        if queue_path:
            stats = get_stats(queue_path)
            total = stats['pending'] + stats['in_progress']

        if total == 0:
            log_info("Queue is empty — nothing to process")
            if progress_callback:
                progress_callback(100)
            return {'processed': 0, 'failed': 0, 'skipped': 0}

        log_info(f"Starting batch processing of {total} items...")
        if progress_callback:
            progress_callback(0)

        processed = 0
        failed = 0
        skipped = 0
        start_time = time.time()
        last_progress_time = start_time

        _consecutive_not_ready = 0
        _earliest_retry_at = float('inf')

        while True:
            if not self.circuit_breaker.can_execute():
                log_warn("Circuit breaker OPEN — Plex may be unavailable")
                log_info(f"Processed {processed} items before circuit break")
                break

            item = self.queue_manager.get_pending(timeout=1)
            if item is None:
                break  # Queue empty

            if not self._is_ready_for_retry(item):
                next_retry = item.get('next_retry_at', 0)
                _earliest_retry_at = min(_earliest_retry_at, next_retry)
                _consecutive_not_ready += 1
                self.queue_manager.nack(item)

                queue_size = max(self.queue_manager.get_queue().size, 50)
                if _consecutive_not_ready >= queue_size:
                    # All items waiting — sleep until earliest retry, cap at 5s
                    # (shorter than background worker's 30s to keep progress bar alive)
                    sleep_secs = max(1.0, min(5.0, _earliest_retry_at - time.time()))
                    log_debug(f"All {_consecutive_not_ready} items in backoff, sleeping {sleep_secs:.1f}s")
                    time.sleep(sleep_secs)
                    _consecutive_not_ready = 0
                    _earliest_retry_at = float('inf')
                else:
                    time.sleep(0.1)
                continue

            _consecutive_not_ready = 0
            _earliest_retry_at = float('inf')

            outcome = self._handle_job(item, recently_synced, sync_timestamps)

            if outcome == 'success':
                processed += 1
                if job_delay_secs > 0:
                    time.sleep(job_delay_secs)
            elif outcome == 'skipped':
                skipped += 1
            elif outcome == 'failed':
                failed += 1
            elif outcome == 'server_down':
                log_info(f"Processed {processed} items before Plex went down")
                break
            # 'retrying' — job requeued with backoff, continue loop

            now = time.time()
            if progress_callback and (
                processed % 5 == 0 or (now - last_progress_time) >= 10
            ):
                progress = min((processed / total) * 100, 100) if total > 0 else 100
                progress_callback(progress)
                remaining = self.queue_manager.get_queue().size
                elapsed = now - start_time
                rate = processed / elapsed if elapsed > 0 else 0
                log_info(
                    f"Progress: {processed}/{total} ({progress:.0f}%), "
                    f"{remaining} remaining, {rate:.1f} items/sec"
                )
                last_progress_time = now

        elapsed = time.time() - start_time
        if progress_callback:
            progress_callback(100)

        summary = f"Batch processing complete: {processed} succeeded, {failed} failed"
        if skipped > 0:
            summary += f", {skipped} duplicates skipped"
        summary += f" in {elapsed:.1f}s"
        log_info(summary)

        if failed > 0:
            dlq_count = self.dlq.get_count()
            log_warn(f"DLQ contains {dlq_count} items requiring review")

        return {'processed': processed, 'failed': failed, 'skipped': skipped}

    def _fetch_stash_image(self, url: str) -> Optional[bytes]:
        """
        Fetch image from Stash URL.

        Downloads the image bytes so we can upload directly to Plex,
        avoiding issues with Plex not being able to reach Stash's internal URL.

        Args:
            url: Stash image URL (screenshot, preview, etc.)

        Returns:
            Image bytes or None if fetch failed
        """
        import urllib.request
        import urllib.error

        try:
            # Build request with authentication from Stash connection
            req = urllib.request.Request(url)

            # Add API key header if available
            api_key = getattr(self.config, 'stash_api_key', None)
            if api_key:
                req.add_header('ApiKey', api_key)

            # Add session cookie if available
            session_cookie = getattr(self.config, 'stash_session_cookie', None)
            if session_cookie:
                req.add_header('Cookie', session_cookie)

            with urllib.request.urlopen(req, timeout=30) as response:
                return response.read()
        except urllib.error.URLError as e:
            log_warn(f" Failed to fetch image from Stash: {e}")
            return None
        except Exception as e:
            log_warn(f" Image fetch error: {e}")
            return None

    def _get_plex_client(self) -> 'PlexClient':
        """
        Get PlexClient with lazy initialization.

        Creates PlexClient on first use to avoid connecting to Plex
        until we actually need to process a job.

        Returns:
            PlexClient instance configured with URL, token, and timeouts
        """
        if self._plex_client is None:
            from plex.client import PlexClient
            self._plex_client = PlexClient(
                url=self.config.plex_url,
                token=self.config.plex_token,
                connect_timeout=self.config.plex_connect_timeout,
                read_timeout=self.config.plex_read_timeout,
            )
        return self._plex_client

    def _get_caches(self) -> tuple[Optional['PlexCache'], Optional['MatchCache']]:
        """
        Get or create cache instances (lazy initialization).

        Caches are only created when data_dir is set. When data_dir is None,
        returns (None, None) and processing continues without caching.

        Returns:
            Tuple of (PlexCache or None, MatchCache or None)
        """
        if self._library_cache is None and self.data_dir is not None:
            from plex.cache import PlexCache, MatchCache
            cache_dir = os.path.join(self.data_dir, 'cache')
            self._library_cache = PlexCache(cache_dir)
            self._match_cache = MatchCache(cache_dir)
            log_debug(f"Initialized caches at {cache_dir}")
        return self._library_cache, self._match_cache

    def _log_cache_stats(self):
        """Log cache hit/miss statistics."""
        library_cache, match_cache = self._get_caches()
        if library_cache is not None:
            stats = library_cache.get_stats()
            total = stats.get('hits', 0) + stats.get('misses', 0)
            if total > 0:
                hit_rate = stats['hits'] / total * 100
                log_debug(f"Library cache: {hit_rate:.1f}% hit rate ({stats['hits']} hits, {stats['misses']} misses)")
        if match_cache is not None:
            stats = match_cache.get_stats()
            total = stats.get('hits', 0) + stats.get('misses', 0)
            if total > 0:
                hit_rate = stats['hits'] / total * 100
                log_info(f"Match cache: {hit_rate:.1f}% hit rate ({stats['hits']} hits, {stats['misses']} misses)")

    def _process_job(self, job: dict) -> Optional[str]:
        """
        Process a sync job by updating Plex metadata.

        Finds the Plex item matching the job's file path and updates
        its metadata based on the update_type.

        Args:
            job: Job dict with scene_id, update_type, data
                - scene_id: Stash scene ID
                - update_type: Type of update (e.g., 'metadata')
                - data: Dict containing 'path' and metadata fields

        Returns:
            Match confidence level ('high' or 'low'), or None if job failed

        Raises:
            TransientError: For retry-able errors (network, timeout)
            PermanentError: For permanent failures (missing path, bad data)
        """
        import time as _time
        _start_time = _time.perf_counter()

        from plex.exceptions import PlexTemporaryError, PlexPermanentError, PlexNotFound, translate_plex_exception
        from plex.matcher import find_plex_items_with_confidence
        from validation.obfuscation import obfuscate_path
        from sync_queue.operations import save_sync_timestamp

        _dbg = getattr(self.config, 'debug_logging', False)

        scene_id = job.get('scene_id')
        data = job.get('data', {})
        file_path = data.get('path')

        if not file_path:
            raise PermanentError(f"Job {scene_id} missing file path")

        if _dbg:
            log_info(f"[DEBUG] Processing scene {scene_id}, path: {obfuscate_path(file_path)}")

        try:
            client = self._get_plex_client()

            # Get library section(s) to search
            configured_libs = self.config.plex_libraries  # parsed comma-separated list
            if configured_libs:
                # Search only the configured libraries
                sections = []
                not_found = []
                for lib_name in configured_libs:
                    try:
                        sections.append(client.server.library.section(lib_name))
                    except Exception:
                        not_found.append(lib_name)
                if not_found:
                    log_warn(f"Libraries not found in Plex: {not_found}")
                if not sections:
                    raise PermanentError(f"None of the configured libraries found: {configured_libs}")
                log_trace(f"Searching {len(sections)} configured library(s): {[s.title for s in sections]}")
            else:
                # Search all libraries (slow)
                sections = client.server.library.sections()
                log_info(f"Searching all {len(sections)} libraries (set plex_library to speed up)")

            if _dbg:
                log_info(f"[DEBUG] Searching {len(sections)} section(s): {[s.title for s in sections]}")

            # Get caches for optimized matching
            library_cache, match_cache = self._get_caches()

            # Search library sections, collect ALL candidates
            all_candidates = []
            # Track which library section each candidate belongs to, so we can
            # write the confirmed match to match_cache after metadata update succeeds.
            _section_by_candidate_key: dict = {}
            for section in sections:
                try:
                    confidence, item, candidates = find_plex_items_with_confidence(
                        section,
                        file_path,
                        library_cache=library_cache,
                        match_cache=match_cache,
                        debug_logging=_dbg,
                    )
                    all_candidates.extend(candidates)
                    for c in candidates:
                        _section_by_candidate_key[c.key] = section.title
                    if _dbg:
                        log_info(f"[DEBUG] Section '{section.title}': {len(candidates)} candidate(s)")
                except PlexNotFound:
                    if _dbg:
                        log_info(f"[DEBUG] Section '{section.title}': no match")
                    continue  # No match in this section, try next

            # Deduplicate candidates (same item might be in multiple sections)
            seen_keys = set()
            unique_candidates = []
            for c in all_candidates:
                if c.key not in seen_keys:
                    seen_keys.add(c.key)
                    unique_candidates.append(c)

            if _dbg:
                log_info(f"[DEBUG] Dedup: {len(all_candidates)} total -> {len(unique_candidates)} unique candidate(s)")

            # Apply confidence scoring
            confidence = None
            if len(unique_candidates) == 0:
                raise PlexNotFound(f"Could not find Plex item for path: {obfuscate_path(file_path)}")
            elif len(unique_candidates) == 1:
                # HIGH confidence - single unique match
                confidence = 'high'
                plex_item = unique_candidates[0]
                if _dbg:
                    log_info(f"[DEBUG] HIGH confidence match: {plex_item.title}")
                self._update_metadata(plex_item, data)
                # Write to match_cache AFTER metadata update succeeds.
                # This ensures the cache only records items that have been
                # fully synced. Writing before the update (as was previously
                # done inside find_plex_items_with_confidence) could cache
                # matches whose metadata was never pushed (e.g. process killed
                # mid-sync), causing subsequent cache-hits to find a Plex item
                # with auto-scanned metadata that "matches" an empty Stash
                # scene and silently skip the real metadata push.
                if match_cache is not None:
                    section_title = _section_by_candidate_key.get(plex_item.key)
                    if section_title:
                        item_key = getattr(plex_item, 'key', None) or str(getattr(plex_item, 'ratingKey', None))
                        if item_key:
                            match_cache.set_match(section_title, file_path, item_key)
            else:
                # LOW confidence - multiple matches
                confidence = 'low'
                paths = [c.media[0].parts[0].file if c.media and c.media[0].parts else c.key for c in unique_candidates]
                obfuscated_paths = [obfuscate_path(p) for p in paths]
                if self.config.strict_matching:
                    log_warn(
                        f"LOW CONFIDENCE SKIPPED: scene {scene_id} "
                        f"Stash path: {obfuscate_path(file_path)} "
                        f"Plex candidates ({len(unique_candidates)}): {obfuscated_paths}"
                    )
                    raise PermanentError("Low confidence match skipped (strict_matching=true)")
                else:
                    plex_item = unique_candidates[0]
                    log_warn(
                        f"LOW CONFIDENCE SYNCED: scene {scene_id} "
                        f"Chosen: {obfuscated_paths[0]} "
                        f"Other candidates: {obfuscated_paths[1:]}"
                    )
                    self._update_metadata(plex_item, data)

            # Update sync timestamp after successful sync
            if self.data_dir is not None:
                save_sync_timestamp(self.data_dir, scene_id, time.time())

            # Log job processing time
            _elapsed = _time.perf_counter() - _start_time
            if _elapsed >= 1.0:
                log_info(f"_process_job took {_elapsed:.3f}s")
            else:
                log_trace(f"_process_job took {_elapsed:.3f}s")

            return confidence

        except (PlexTemporaryError, PlexPermanentError, PlexNotFound):
            raise
        except Exception as e:
            raise translate_plex_exception(e)

    def _validate_edit_result(self, plex_item, expected_edits: dict) -> list:
        """
        Validate that edit actually applied expected values.

        Returns list of fields that may not have updated correctly.
        This catches silent failures where Plex accepts the request
        but doesn't apply the value (e.g., field limit exceeded).

        Args:
            plex_item: Plex item after reload
            expected_edits: Dict of edits that were sent (field.value -> value)

        Returns:
            List of issue descriptions for fields that may not have updated
        """
        issues = []
        for field_key, expected_value in expected_edits.items():
            # Skip locked fields and non-value fields
            if '.locked' in field_key or not expected_value:
                continue

            # Parse field name from "field.value" format
            field_name = field_key.replace('.value', '')

            # Map edit field names to actual plex_item attributes
            field_mapping = {
                'title': 'title',
                'studio': 'studio',
                'summary': 'summary',
                'tagline': 'tagline',
                'originallyAvailableAt': 'originallyAvailableAt',
            }

            attr_name = field_mapping.get(field_name)
            if not attr_name:
                continue

            actual_value = getattr(plex_item, attr_name, None)

            # Convert to string for comparison (handle None)
            expected_str = str(expected_value) if expected_value else ''
            actual_str = str(actual_value) if actual_value else ''

            # Check if value matches (with tolerance for truncation/sanitization)
            # Compare first 50 chars to handle any server-side trimming
            if expected_str and actual_str:
                if expected_str[:50] != actual_str[:50]:
                    issues.append(
                        f"{field_name}: sent '{expected_str[:20]}...', "
                        f"got '{actual_str[:20]}...'"
                    )
            elif expected_str and not actual_str:
                issues.append(f"{field_name}: sent value but field is empty")

        return issues

    def _update_metadata(self, plex_item, data: dict):
        """
        Update Plex item metadata from sync job data with granular error handling.

        Implements LOCKED user decision: When Stash provides None/empty for an
        optional field, the existing Plex value is CLEARED (not preserved).
        When a field key is NOT in the data dict, the existing value is preserved.

        Non-critical field failures (performers, tags, poster, background, collection)
        are logged as warnings but don't fail the overall sync. Critical field failures
        (core metadata edit) propagate and fail the job.

        Args:
            plex_item: Plex Video item to update
            data: Dict containing metadata fields (title, studio, details, etc.)

        Returns:
            PartialSyncResult tracking which fields succeeded and which had warnings
        """
        from validation.errors import PartialSyncResult

        _dbg = getattr(self.config, 'debug_logging', False)
        result = PartialSyncResult()

        if not getattr(self.config, 'sync_master', True):
            log_debug("Master sync toggle is OFF - skipping all field syncs")
            return result

        # Phase 1: Build and apply core text field edits (CRITICAL - failure propagates)
        edits = self._build_core_edits(plex_item, data)
        _needs_reload = False
        if edits:
            if _dbg:
                log_info(f"[DEBUG] Metadata edits: {edits}")
            else:
                log_debug(f"Updating fields: {list(edits.keys())}")
            plex_item.edit(**edits)
            _needs_reload = True
            mode = "preserved" if self.config.preserve_plex_edits else "overwrite"
            log_info(f"Updated metadata ({mode} mode): {plex_item.title}")
            result.add_success('metadata')
        else:
            if _dbg:
                # Log what was compared so we can diagnose "no-op" syncs
                fields_in_data = [k for k in ('title', 'studio', 'details', 'summary', 'tagline', 'date') if k in data]
                log_info(f"[DEBUG] No core edits for '{plex_item.title}' — "
                         f"data keys present: {fields_in_data}, "
                         f"plex title='{plex_item.title}', stash title='{data.get('title', '<missing>')}'")
            else:
                log_trace(f"No metadata fields to update for: {plex_item.title}")

        # Phase 2: Non-critical field syncs (failures logged as warnings)
        if getattr(self.config, 'sync_performers', True) and 'performers' in data:
            _needs_reload |= self._sync_performers(plex_item, data, result, _dbg)

        if getattr(self.config, 'sync_poster', True) and data.get('poster_url'):
            self._upload_image(
                plex_item, data['poster_url'], plex_item.uploadPoster, 'poster', result, _dbg)

        if getattr(self.config, 'sync_background', True) and data.get('background_url'):
            self._upload_image(
                plex_item, data['background_url'], plex_item.uploadArt, 'background', result, _dbg)

        if getattr(self.config, 'sync_tags', True) and 'tags' in data:
            _needs_reload |= self._sync_tags(plex_item, data, result, _dbg)

        if getattr(self.config, 'sync_collection', True) and data.get('studio'):
            _needs_reload |= self._sync_collection(plex_item, data, result)

        # Single deferred reload after all edits (reduces HTTP roundtrips from up to 6 to 1)
        if _needs_reload:
            try:
                plex_item.reload()
                if edits:
                    validation_issues = self._validate_edit_result(plex_item, edits)
                    if validation_issues:
                        log_debug(f"Edit validation issues (may be expected): {validation_issues}")
            except Exception as e:
                log_debug(f"Post-edit reload failed (edits already applied): {e}")

        if result.has_warnings:
            log_warn(f"Partial sync for {plex_item.title}: {result.warning_summary}")

        return result

    def _build_core_edits(self, plex_item, data: dict) -> dict:
        """Build dict of core text field edits (title, studio, summary, tagline, date).

        LOCKED DECISION: Missing optional fields clear existing Plex values.
        - If key exists AND value is None/empty -> CLEAR (set to '')
        - If key exists AND value is present -> sanitize and set
        - If key does NOT exist in data dict -> do nothing (preserve)
        """
        from validation.limits import (
            MAX_TITLE_LENGTH, MAX_STUDIO_LENGTH, MAX_SUMMARY_LENGTH, MAX_TAGLINE_LENGTH,
        )
        from validation.sanitizers import sanitize_for_plex

        edits = {}

        # Title (always synced — no toggle)
        # NEVER clear a Plex title to empty — an empty title in Stash usually means
        # the scene was just scanned and not yet identified. Clearing Plex's
        # auto-generated title would leave the item nameless.
        if 'title' in data:
            title_value = data.get('title')
            if title_value is None or title_value == '':
                # Stash has no title — preserve whatever Plex already has.
                # This prevents race conditions where Scene.Update.Post fires
                # before identification completes.
                log_debug("Stash title is empty — preserving existing Plex title")
            else:
                sanitized = sanitize_for_plex(title_value, max_length=MAX_TITLE_LENGTH)
                if not self.config.preserve_plex_edits or not plex_item.title:
                    if (plex_item.title or '') != sanitized:
                        edits['title.value'] = sanitized

        # Studio
        if getattr(self.config, 'sync_studio', True) and 'studio' in data:
            studio_value = data.get('studio')
            if studio_value is None or studio_value == '':
                if plex_item.studio:
                    edits['studio.value'] = ''
                    log_debug("Clearing studio (Stash value is empty)")
            else:
                sanitized = sanitize_for_plex(studio_value, max_length=MAX_STUDIO_LENGTH)
                if not self.config.preserve_plex_edits or not plex_item.studio:
                    if (plex_item.studio or '') != sanitized:
                        edits['studio.value'] = sanitized

        # Summary (Stash 'details' -> Plex 'summary')
        if getattr(self.config, 'sync_summary', True):
            has_summary_key = 'details' in data or 'summary' in data
            if has_summary_key:
                summary_value = data.get('details') or data.get('summary')
                if summary_value is None or summary_value == '':
                    if plex_item.summary:
                        edits['summary.value'] = ''
                        log_debug("Clearing summary (Stash value is empty)")
                else:
                    sanitized = sanitize_for_plex(summary_value, max_length=MAX_SUMMARY_LENGTH)
                    if not self.config.preserve_plex_edits or not plex_item.summary:
                        if (plex_item.summary or '') != sanitized:
                            edits['summary.value'] = sanitized

        # Tagline
        if getattr(self.config, 'sync_tagline', True) and 'tagline' in data:
            tagline_value = data.get('tagline')
            if tagline_value is None or tagline_value == '':
                if getattr(plex_item, 'tagline', None):
                    edits['tagline.value'] = ''
                    log_debug("Clearing tagline (Stash value is empty)")
            else:
                sanitized = sanitize_for_plex(tagline_value, max_length=MAX_TAGLINE_LENGTH)
                if not self.config.preserve_plex_edits or not getattr(plex_item, 'tagline', None):
                    if (getattr(plex_item, 'tagline', '') or '') != sanitized:
                        edits['tagline.value'] = sanitized

        # Date
        if getattr(self.config, 'sync_date', True) and 'date' in data:
            date_value = data.get('date')
            if date_value is None or date_value == '':
                if getattr(plex_item, 'originallyAvailableAt', None):
                    edits['originallyAvailableAt.value'] = ''
                    log_debug("Clearing date (Stash value is empty)")
            else:
                if not self.config.preserve_plex_edits or not getattr(plex_item, 'originallyAvailableAt', None):
                    current_date = getattr(plex_item, 'originallyAvailableAt', None)
                    current_date_str = current_date.strftime('%Y-%m-%d') if current_date else ''
                    if current_date_str != (date_value or ''):
                        edits['originallyAvailableAt.value'] = date_value

        return edits

    def _sync_performers(self, plex_item, data: dict, result, _dbg: bool) -> bool:
        """Sync performers as Plex actors. Returns True if reload needed.

        LOCKED: If 'performers' key exists with empty/None, clear all actors.
        """
        from validation.limits import MAX_PERFORMER_NAME_LENGTH, MAX_PERFORMERS
        from validation.sanitizers import sanitize_for_plex

        performers = data.get('performers')
        if performers is None or performers == []:
            try:
                plex_item.edit(**{'actor.locked': 1})
                log_debug("Clearing performers (Stash value is empty)")
                result.add_success('performers')
                return True
            except Exception as e:
                log_warn(f" Failed to clear performers: {e}")
                result.add_warning('performers', e)
                return False

        if not performers:
            return False

        try:
            sanitized = [sanitize_for_plex(p, max_length=MAX_PERFORMER_NAME_LENGTH) for p in performers]
            if len(sanitized) > MAX_PERFORMERS:
                log_warn(f"Truncating performers list from {len(sanitized)} to {MAX_PERFORMERS}")
                sanitized = sanitized[:MAX_PERFORMERS]

            current_actors = [actor.tag for actor in getattr(plex_item, 'actors', [])]
            new_performers = [p for p in sanitized if p not in current_actors]

            if _dbg:
                log_info(f"[DEBUG] Performers: current={current_actors}, new={new_performers}")

            if new_performers:
                all_actors = current_actors + new_performers
                if len(all_actors) > MAX_PERFORMERS:
                    log_warn(f"Truncating combined actors list from {len(all_actors)} to {MAX_PERFORMERS}")
                    all_actors = all_actors[:MAX_PERFORMERS]
                actor_edits = {f'actor[{i}].tag.tag': name for i, name in enumerate(all_actors)}
                plex_item.edit(**actor_edits)
                log_info(f"Added {len(new_performers)} performers: {new_performers}")
                result.add_success('performers')
                return True
            else:
                log_trace(f"Performers already in Plex: {sanitized}")
                result.add_success('performers')
                return False
        except Exception as e:
            log_warn(f" Failed to sync performers: {e}")
            result.add_warning('performers', e)
            return False

    def _upload_image(self, plex_item, url: str, upload_fn, field_name: str, result, _dbg: bool):
        """Download image from Stash and upload to Plex.

        Args:
            plex_item: Plex Video item
            url: Stash image URL
            upload_fn: Plex upload method (uploadPoster or uploadArt)
            field_name: Field name for result tracking ('poster' or 'background')
            result: PartialSyncResult to record outcome
            _dbg: Debug logging flag
        """
        try:
            if _dbg:
                log_info(f"[DEBUG] Fetching {field_name} image from Stash")
            image_data = self._fetch_stash_image(url)
            if image_data:
                import tempfile
                import os
                with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as f:
                    f.write(image_data)
                    temp_path = f.name
                try:
                    upload_fn(filepath=temp_path)
                    log_debug(f"Uploaded {field_name} ({len(image_data)} bytes)")
                    result.add_success(field_name)
                finally:
                    os.unlink(temp_path)
            else:
                result.add_warning(field_name, ValueError("No image data returned from Stash"))
        except Exception as e:
            log_warn(f" Failed to upload {field_name}: {e}")
            result.add_warning(field_name, e)

    def _sync_tags(self, plex_item, data: dict, result, _dbg: bool) -> bool:
        """Sync tags as Plex genres. Returns True if reload needed.

        LOCKED: If 'tags' key exists with empty/None, clear all genres.
        """
        from validation.limits import MAX_TAG_NAME_LENGTH, MAX_TAGS
        from validation.sanitizers import sanitize_for_plex

        max_tags = getattr(self.config, 'max_tags', MAX_TAGS)
        tags = data.get('tags')

        if tags is None or tags == []:
            try:
                plex_item.edit(**{'genre.locked': 1})
                log_debug("Clearing tags (Stash value is empty)")
                result.add_success('tags')
                return True
            except Exception as e:
                log_warn(f" Failed to clear tags: {e}")
                result.add_warning('tags', e)
                return False

        if not tags:
            return False

        try:
            sanitized = [sanitize_for_plex(t, max_length=MAX_TAG_NAME_LENGTH) for t in tags]
            if len(sanitized) > max_tags:
                log_warn(f"Truncating tags list from {len(sanitized)} to {max_tags}")
                sanitized = sanitized[:max_tags]

            current_genres = [g.tag for g in getattr(plex_item, 'genres', [])]
            if _dbg:
                log_info(f"[DEBUG] Tags: current={current_genres}, new_from_stash={sanitized}")
            new_tags = [t for t in sanitized if t not in current_genres]

            if new_tags:
                all_genres = current_genres + new_tags
                if len(all_genres) > max_tags:
                    log_warn(f"Truncating combined tags list from {len(all_genres)} to {max_tags}")
                    all_genres = all_genres[:max_tags]
                genre_edits = {f'genre[{i}].tag.tag': name for i, name in enumerate(all_genres)}
                plex_item.edit(**genre_edits)
                log_info(f"Added {len(new_tags)} tags as genres: {new_tags}")
                result.add_success('tags')
                return True
            else:
                log_trace(f"Tags already in Plex: {sanitized}")
                result.add_success('tags')
                return False
        except Exception as e:
            log_warn(f" Failed to sync tags: {e}")
            result.add_warning('tags', e)
            return False

    def _sync_collection(self, plex_item, data: dict, result) -> bool:
        """Add item to studio-based Plex collection. Returns True if reload needed."""
        studio = data.get('studio')
        try:
            current_collections = [c.tag for c in getattr(plex_item, 'collections', [])]
            if studio not in current_collections:
                all_collections = current_collections + [studio]
                coll_edits = {f'collection[{i}].tag.tag': name for i, name in enumerate(all_collections)}
                plex_item.edit(**coll_edits)
                log_debug(f"Added to collection: {studio}")
                result.add_success('collection')
                return True
            else:
                log_trace(f"Already in collection: {studio}")
                result.add_success('collection')
                return False
        except Exception as e:
            log_warn(f" Failed to add to collection: {e}")
            result.add_warning('collection', e)
            return False
