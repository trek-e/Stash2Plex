"""
Background worker for processing sync jobs.

Implements reliable job processing with acknowledgment workflow:
- Acknowledges successful jobs
- Retries transient failures with exponential backoff
- Moves permanently failed jobs to DLQ
- Circuit breaker pauses processing during Plex outages
"""

import os
import sys
import time
import threading
from typing import Optional, TYPE_CHECKING

from worker.stats import SyncStats

# Lazy imports to avoid circular import with validation module
# These are imported inside _update_metadata() where they're used

from shared.log import create_logger
log_trace, log_debug, log_info, log_warn, log_error = create_logger("Worker")

from worker.errors import TransientError, PermanentError
from worker.backoff import calculate_delay, get_retry_params
from worker.circuit_breaker import CircuitBreaker, CircuitState
# plex.exceptions imports are lazy (inside methods) due to circular import:
# plex.exceptions → worker.errors → worker.__init__ → worker.processor → plex.exceptions

# Remaining lazy imports are inside methods — see # lazy: comments for reasons

if TYPE_CHECKING:
    from validation.config import Stash2PlexConfig
    from plex.client import PlexClient
    from plex.cache import PlexCache, MatchCache


class SyncWorker:
    """
    Background worker that processes sync jobs from the queue.

    Runs in a daemon thread and processes jobs with proper acknowledgment:
    - Success: ack_job
    - Transient failure: exponential backoff retry with metadata in job
    - Permanent failure or max retries: fail_job + DLQ
    - Circuit breaker: pauses processing after consecutive failures
    """

    def __init__(
        self,
        queue,
        dlq: 'DeadLetterQueue',
        config: 'Stash2PlexConfig',
        data_dir: Optional[str] = None,
        max_retries: int = 5,
    ):
        """
        Initialize sync worker.

        Args:
            queue: SQLiteAckQueue instance
            dlq: DeadLetterQueue for permanently failed jobs
            config: Stash2PlexConfig with Plex URL, token, and timeouts
            data_dir: Plugin data directory for sync timestamp updates
            max_retries: Maximum retry attempts before moving to DLQ (default for standard errors)
        """
        self.queue = queue
        self.dlq = dlq
        self.config = config
        self.data_dir = data_dir
        self.max_retries = max_retries
        self.running = False
        self.thread: Optional[threading.Thread] = None
        self._plex_client: Optional['PlexClient'] = None

        # Initialize caches (lazy, created on first use)
        self._library_cache: Optional['PlexCache'] = None
        self._match_cache: Optional['MatchCache'] = None
        self._metadata_updater = None

        # Initialize stats tracking
        self._stats = SyncStats()
        if data_dir is not None:
            stats_path = os.path.join(data_dir, 'stats.json')
            self._stats = SyncStats.load_from_file(stats_path)

        # DLQ status logging interval
        self._jobs_since_dlq_log = 0
        self._dlq_log_interval = 10  # Log DLQ status every 10 jobs

        # Outage history tracking
        if data_dir is not None:
            from worker.outage_history import OutageHistory  # lazy: only needed when data_dir is set
            self._outage_history = OutageHistory(data_dir)
        else:
            self._outage_history = None

        # Circuit breaker for resilience during Plex outages
        # Enable state persistence when data_dir is available
        cb_state_file = None
        if data_dir is not None:
            cb_state_file = os.path.join(data_dir, 'circuit_breaker.json')

        self.circuit_breaker = CircuitBreaker(
            failure_threshold=5,
            recovery_timeout=60.0,
            success_threshold=1,
            state_file=cb_state_file,
            outage_history=self._outage_history
        )

        # Health check state for active probes during OPEN circuit
        self._last_health_check: float = 0.0
        self._health_check_interval: float = 5.0  # Initial: 5s
        self._consecutive_health_failures: int = 0

        # Recovery rate limiter for graduated queue drain
        from worker.rate_limiter import RecoveryRateLimiter  # lazy: only needed at init time
        self._rate_limiter = RecoveryRateLimiter()
        self._was_in_recovery = False

        # Check if recovery period is active from prior session (cross-restart continuity)
        if data_dir is not None:
            from worker.recovery import RecoveryScheduler  # lazy: only needed when data_dir is set
            recovery_scheduler = RecoveryScheduler(data_dir, outage_history=self._outage_history)
            recovery_state = recovery_scheduler.load_state()
            if recovery_state.recovery_started_at > 0:
                # Recovery period was active before restart — resume from current position
                self._rate_limiter.start_recovery_period(now=recovery_state.recovery_started_at)
                self._was_in_recovery = True
                log_info("Resuming recovery rate limiting from prior session")

    def start(self):
        """Start the background worker thread"""
        if self.running:
            log_trace("Already running")
            return

        # Cleanup old DLQ entries
        retention_days = getattr(self.config, 'dlq_retention_days', 30)
        self.dlq.delete_older_than(days=retention_days)

        # Log DLQ status on startup
        self._log_dlq_status()

        self.running = True
        self.thread = threading.Thread(target=self._worker_loop, daemon=True)
        self.thread.start()
        log_info("Started")

    def _log_dlq_status(self):
        """Log DLQ status if jobs present."""
        count = self.dlq.get_count()
        if count > 0:
            log_warn(f"DLQ contains {count} failed jobs requiring review")
            recent = self.dlq.get_recent(limit=5)
            for entry in recent:
                log_debug(
                    f"DLQ #{entry['id']}: scene {entry['scene_id']} - "
                    f"{entry['error_type']}: {entry['error_message'][:80]}"
                )

    def _log_batch_summary(self):
        """Log periodic summary of sync operations with JSON stats."""
        import json

        stats = self._stats

        # Human-readable summary line
        log_info(
            f"Sync summary: {stats.jobs_succeeded}/{stats.jobs_processed} succeeded "
            f"({stats.success_rate:.1f}%), avg {stats.avg_processing_time*1000:.0f}ms, "
            f"confidence: {stats.high_confidence_matches} high / {stats.low_confidence_matches} low"
        )

        # JSON batch summary for machine parsing
        stats_dict = {
            "processed": stats.jobs_processed,
            "succeeded": stats.jobs_succeeded,
            "failed": stats.jobs_failed,
            "to_dlq": stats.jobs_to_dlq,
            "success_rate": f"{stats.success_rate:.1f}%",
            "avg_time_ms": int(stats.avg_processing_time * 1000),
            "high_confidence": stats.high_confidence_matches,
            "low_confidence": stats.low_confidence_matches,
            "errors_by_type": stats.errors_by_type,
        }
        log_info(f"Stats: {json.dumps(stats_dict)}")

        # DLQ summary if items present (using get_error_summary method)
        dlq_summary = self.dlq.get_error_summary()
        if dlq_summary:
            total = sum(dlq_summary.values())
            breakdown = ", ".join(f"{count} {err_type}" for err_type, count in dlq_summary.items())
            log_warn(f"DLQ contains {total} items: {breakdown}")

    def stop(self):
        """Stop the background worker thread, letting current job finish."""
        if not self.running:
            return

        log_trace("Stopping worker...")
        self.running = False

        if self.thread:
            # Give current job time to finish (get timeout=2s + processing)
            self.thread.join(timeout=10)
            if self.thread.is_alive():
                log_warn("Worker thread did not stop within 10s — current job may be reprocessed")

        log_trace("Worker stopped")

    def _prepare_for_retry(self, job: dict, error: Exception) -> dict:
        """
        Add retry metadata to job before re-enqueueing.

        Stores retry_count, next_retry_at, and last_error_type in job dict
        so retry state survives worker restart (crash-safe).

        Args:
            job: Job dict to update
            error: The exception that caused the retry

        Returns:
            Updated job dict with retry metadata
        """
        base, cap, max_retries = get_retry_params(error)
        retry_count = job.get('retry_count', 0) + 1
        delay = calculate_delay(retry_count - 1, base, cap)  # -1 because we just incremented

        job['retry_count'] = retry_count
        job['next_retry_at'] = time.time() + delay
        job['last_error_type'] = type(error).__name__
        return job

    def _is_ready_for_retry(self, job: dict) -> bool:
        """
        Check if job's backoff delay has elapsed.

        Args:
            job: Job dict with optional next_retry_at field

        Returns:
            True if job is ready for processing (no delay or delay elapsed)
        """
        next_retry_at = job.get('next_retry_at', 0)
        return time.time() >= next_retry_at

    def _get_max_retries_for_error(self, error: Exception) -> int:
        """
        Get max retries based on error type.

        PlexNotFound errors get more retries (12) to allow for library scanning.
        Other transient errors use the standard max_retries (5).

        Args:
            error: The exception that triggered the retry

        Returns:
            Maximum number of retries for this error type
        """
        _, _, max_retries = get_retry_params(error)
        return max_retries

    def _requeue_with_metadata(self, job: dict):
        """
        Re-enqueue job with updated retry metadata.

        persist-queue's nack() doesn't support modifying job data,
        so we ack the current job and enqueue a fresh copy with
        updated metadata.

        Args:
            job: Job dict with retry metadata already added
        """
        from sync_queue.operations import ack_job as _ack_job, _job_counter  # lazy: test isolation

        # Extract original job fields for re-enqueue
        scene_id = job.get('scene_id')
        update_type = job.get('update_type')
        data = job.get('data', {})

        # Create new job with all metadata preserved
        new_job = {
            'job_id': next(_job_counter),
            'scene_id': scene_id,
            'update_type': update_type,
            'data': data,
            'enqueued_at': job.get('enqueued_at', time.time()),
            'job_key': job.get('job_key', f"scene_{scene_id}"),
            # Preserve retry metadata
            'retry_count': job.get('retry_count', 0),
            'next_retry_at': job.get('next_retry_at', 0),
            'last_error_type': job.get('last_error_type'),
        }

        # Ack the old job (removes from queue)
        _ack_job(self.queue, job)
        # Enqueue fresh copy with metadata
        self.queue.put(new_job)

    def _worker_loop(self):
        """Main worker loop - runs in background thread"""
        from plex.exceptions import PlexServerDown, PlexNotFound  # lazy: circular import (plex.exceptions→worker→plex.exceptions)
        from sync_queue.operations import get_pending, ack_job, nack_job, fail_job  # lazy: test isolation

        # Track recently-processed scene IDs to skip duplicates within this session.
        _recently_synced: set = set()

        # Load sync timestamps for cross-session dedup.
        # If a scene was already synced (timestamp exists and no newer update),
        # skip it — prevents the same scene from being reprocessed every plugin
        # invocation due to auto_resume or stale queue entries.
        _sync_timestamps: dict = {}
        if self.data_dir is not None:
            from sync_queue.operations import load_sync_timestamps as _load_ts  # lazy: test isolation
            _sync_timestamps = _load_ts(self.data_dir)

        # Track consecutive not-ready nacks to detect when ALL items are waiting
        # for backoff. Without this, the worker spins dequeuing and nacking
        # thousands of not-ready items per second (the "queue balloon" bug).
        _consecutive_not_ready = 0
        _earliest_retry_at = float('inf')

        while self.running:
            try:
                _dbg = getattr(self.config, 'debug_logging', False)

                # Check circuit breaker first - pause if Plex is down
                if not self.circuit_breaker.can_execute():
                    if _dbg:
                        log_info(f"[DEBUG] Circuit breaker state={self.circuit_breaker.state.value}, sleeping {self.config.poll_interval}s")

                    # Active health check during OPEN state to detect recovery
                    now = time.time()
                    if now - self._last_health_check >= self._health_check_interval:
                        from plex.health import check_plex_health  # lazy: imports plexapi

                        client = self._get_plex_client()
                        is_healthy, latency_ms = check_plex_health(client, timeout=5.0)
                        self._last_health_check = now

                        if is_healthy:
                            # Plex is back online
                            log_info(f"Plex health check passed ({latency_ms:.0f}ms), recovery possible")
                            self._consecutive_health_failures = 0
                            self._health_check_interval = 5.0
                            # NOTE: Do NOT directly modify circuit breaker state here.
                            # Circuit breaker's own recovery_timeout handles OPEN->HALF_OPEN transition.
                            # This health check is informational - the next can_execute() call will
                            # naturally transition to HALF_OPEN if timeout has elapsed.
                        else:
                            # Plex still down, apply backoff
                            self._consecutive_health_failures += 1
                            self._health_check_interval = calculate_delay(
                                retry_count=self._consecutive_health_failures,
                                base=5.0,
                                cap=60.0,
                                jitter_seed=None  # Random jitter in production
                            )
                            log_debug(f"Plex health check failed (attempt #{self._consecutive_health_failures}), next check in {self._health_check_interval:.1f}s")

                    # Sleep in small increments so stop() can interrupt quickly
                    for _ in range(int(self.config.poll_interval * 2)):
                        if not self.running:
                            return
                        time.sleep(0.5)
                    continue

                # Rate limit during recovery period (graduated queue drain)
                wait_time = self._rate_limiter.should_wait()
                if wait_time > 0:
                    if _dbg:
                        log_info(f"[DEBUG] Recovery rate limit: waiting {wait_time:.2f}s (rate={self._rate_limiter.current_rate():.1f}/s)")
                    # Sleep in small chunks so stop() can interrupt quickly
                    remaining = wait_time
                    while remaining > 0 and self.running:
                        chunk = min(remaining, 0.5)
                        time.sleep(chunk)
                        remaining -= chunk
                    continue

                # Check if recovery period ended (ramp complete)
                if not self._rate_limiter.is_in_recovery_period() and self._was_in_recovery:
                    self._was_in_recovery = False
                    if self.data_dir is not None:
                        from worker.recovery import RecoveryScheduler  # lazy: only needed when data_dir is set
                        scheduler = RecoveryScheduler(self.data_dir, outage_history=self._outage_history)
                        scheduler.clear_recovery_period()
                    log_info("Recovery period complete: normal processing speed resumed")

                # Get next pending job (2 second timeout — short so stop() isn't blocked)
                item = get_pending(self.queue, timeout=2)
                if item is None:
                    if _dbg:
                        log_info("[DEBUG] Queue poll: timeout, no items")
                    continue

                # Check if backoff delay has elapsed
                if not self._is_ready_for_retry(item):
                    next_retry = item.get('next_retry_at', 0)
                    _earliest_retry_at = min(_earliest_retry_at, next_retry)
                    _consecutive_not_ready += 1

                    if _dbg:
                        remaining = next_retry - time.time()
                        _dbg_id = item.get('job_id') or item.get('scene_id')
                        log_info(f"[DEBUG] Job {_dbg_id} backoff not elapsed ({remaining:.1f}s remaining), streak={_consecutive_not_ready}")

                    nack_job(self.queue, item)

                    # If we've cycled through many not-ready items without finding
                    # a ready one, all items are waiting for backoff. Sleep until
                    # the earliest retry time instead of spinning.
                    # Threshold: after 50 consecutive not-ready nacks (or queue.size,
                    # whichever is larger), assume everything is waiting.
                    queue_size = max(self.queue.size, 50)
                    if _consecutive_not_ready >= queue_size:
                        sleep_until = _earliest_retry_at - time.time()
                        # Clamp to [1, 30] seconds — don't sleep too long (stop() responsiveness)
                        # and don't sleep too short (avoid hot loop)
                        sleep_secs = max(1.0, min(30.0, sleep_until))
                        if _dbg:
                            log_info(f"[DEBUG] All {_consecutive_not_ready} items waiting for backoff, sleeping {sleep_secs:.1f}s")
                        else:
                            log_debug(f"All {_consecutive_not_ready} items waiting for backoff, sleeping {sleep_secs:.1f}s")
                        # Sleep in small chunks so stop() can interrupt
                        remaining_sleep = sleep_secs
                        while remaining_sleep > 0 and self.running:
                            chunk = min(remaining_sleep, 0.5)
                            time.sleep(chunk)
                            remaining_sleep -= chunk
                        # Reset counters for next cycle
                        _consecutive_not_ready = 0
                        _earliest_retry_at = float('inf')
                    else:
                        time.sleep(0.1)  # Small delay between individual nacks
                    continue

                # Item is ready — reset not-ready streak
                _consecutive_not_ready = 0
                _earliest_retry_at = float('inf')

                scene_id = item.get('scene_id')
                jid = item.get('job_id') or scene_id
                retry_count = item.get('retry_count', 0)

                # Skip duplicate scene IDs (queue may have multiple entries from
                # overlapping reconciliation runs, repeated hooks, or retry copies)
                if scene_id is not None and scene_id in _recently_synced:
                    ack_job(self.queue, item)
                    log_debug(f"Job {jid} skipped — scene {scene_id} already synced this session")
                    continue

                # Cross-session dedup: if this scene was already synced and the
                # enqueued_at timestamp is OLDER than the last sync, it's a stale
                # queue entry (auto_resume resurrection or leftover from prior session).
                # Skip it to prevent the same scene from being re-processed every
                # plugin invocation.
                if scene_id is not None and _sync_timestamps:
                    enqueued_at = item.get('enqueued_at', 0)
                    last_synced = _sync_timestamps.get(int(scene_id))
                    if last_synced and enqueued_at <= last_synced and retry_count == 0:
                        ack_job(self.queue, item)
                        log_debug(f"Job {jid} skipped — scene {scene_id} already synced (enqueued {enqueued_at:.0f} <= synced {last_synced:.0f})")
                        continue

                log_debug(f"Processing job {jid} for scene {scene_id} (attempt {retry_count + 1})")

                _job_start = time.perf_counter()
                try:
                    # Process the job and get match confidence
                    confidence = self._process_job(item)
                    _job_elapsed = time.perf_counter() - _job_start

                    # Record success with stats
                    self._stats.record_success(_job_elapsed, confidence=confidence or 'high')

                    # Success: acknowledge job and record with circuit breaker
                    previous_state = self.circuit_breaker.state
                    ack_job(self.queue, item)
                    self.circuit_breaker.record_success()

                    # Record result with rate limiter for error monitoring
                    self._rate_limiter.record_result(success=True)

                    # Detect recovery: HALF_OPEN -> CLOSED transition starts recovery period
                    if previous_state == CircuitState.HALF_OPEN and self.circuit_breaker.state == CircuitState.CLOSED:
                        self._rate_limiter.start_recovery_period()
                        self._was_in_recovery = True
                        # Persist recovery_started_at for cross-restart continuity
                        if self.data_dir is not None:
                            from worker.recovery import RecoveryScheduler  # lazy: only needed when data_dir is set
                            scheduler = RecoveryScheduler(self.data_dir, outage_history=self._outage_history)
                            state = scheduler.load_state()
                            state.recovery_started_at = time.time()
                            scheduler.save_state(state)
                        log_info("Recovery period started: graduated rate limiting enabled")

                    log_info(f"Job {jid} completed")

                    # Track for dedup (skip future duplicates of this scene)
                    if scene_id is not None:
                        _recently_synced.add(scene_id)

                    # Brief pause between jobs to avoid overwhelming Plex
                    time.sleep(0.15)

                    # Periodic batch summary and cache status logging
                    self._jobs_since_dlq_log += 1
                    if self._jobs_since_dlq_log >= self._dlq_log_interval:
                        self._log_batch_summary()
                        self._log_cache_stats()
                        self._jobs_since_dlq_log = 0

                        # Save stats periodically
                        if self.data_dir is not None:
                            stats_path = os.path.join(self.data_dir, 'stats.json')
                            self._stats.save_to_file(stats_path)

                except PlexServerDown:
                    # Server unreachable: don't count against retry limit
                    # Nack job back to queue, circuit breaker pauses processing
                    nack_job(self.queue, item)
                    self.circuit_breaker.record_failure()

                    # Record result with rate limiter for error monitoring
                    self._rate_limiter.record_result(success=False)

                    if self.circuit_breaker.state == CircuitState.OPEN:
                        pending = self.queue.size
                        log_warn(f"Plex server is down — pausing, {pending} job(s) waiting")

                except PlexNotFound as e:
                    # Item not in Plex library (not yet scanned).
                    # Does NOT count against circuit breaker — this is an
                    # item-level issue, not a server outage.
                    _job_elapsed = time.perf_counter() - _job_start

                    # Prepare job for retry with backoff metadata
                    job = self._prepare_for_retry(item, e)
                    max_retries = self._get_max_retries_for_error(e)
                    job_retry_count = job.get('retry_count', 0)

                    if job_retry_count >= max_retries:
                        log_warn(f"Job {jid} exceeded max retries ({max_retries}), moving to DLQ")
                        fail_job(self.queue, item)
                        self.dlq.add(job, e, job_retry_count)
                        self._stats.record_failure(type(e).__name__, _job_elapsed, to_dlq=True)
                    else:
                        delay = job.get('next_retry_at', 0) - time.time()
                        log_debug(f"Job {jid} not in Plex yet (attempt {job_retry_count}/{max_retries}), retry in {delay:.1f}s")
                        self._requeue_with_metadata(job)
                        self._stats.record_failure(type(e).__name__, _job_elapsed, to_dlq=False)

                except TransientError as e:
                    _job_elapsed = time.perf_counter() - _job_start
                    # Record failure with circuit breaker
                    self.circuit_breaker.record_failure()

                    # Record result with rate limiter for error monitoring
                    self._rate_limiter.record_result(success=False)

                    if self.circuit_breaker.state == CircuitState.OPEN:
                        log_warn(f"Circuit breaker OPENED after {type(e).__name__}: {e}")

                    # Prepare job for retry with backoff metadata
                    job = self._prepare_for_retry(item, e)
                    max_retries = self._get_max_retries_for_error(e)
                    job_retry_count = job.get('retry_count', 0)

                    if job_retry_count >= max_retries:
                        log_warn(f"Job {jid} exceeded max retries ({max_retries}), moving to DLQ")
                        fail_job(self.queue, item)
                        self.dlq.add(job, e, job_retry_count)
                        self._stats.record_failure(type(e).__name__, _job_elapsed, to_dlq=True)
                    else:
                        delay = job.get('next_retry_at', 0) - time.time()
                        log_debug(f"Job {jid} failed (attempt {job_retry_count}/{max_retries}), retry in {delay:.1f}s: {e}")
                        self._requeue_with_metadata(job)
                        self._stats.record_failure(type(e).__name__, _job_elapsed, to_dlq=False)

                except PermanentError as e:
                    _job_elapsed = time.perf_counter() - _job_start
                    # Permanent error: move to DLQ immediately (doesn't count against circuit)
                    log_error(f"Job {jid} permanent failure, moving to DLQ: {e}")
                    fail_job(self.queue, item)
                    self.dlq.add(item, e, item.get('retry_count', 0))
                    self._stats.record_failure(type(e).__name__, _job_elapsed, to_dlq=True)

                except Exception as e:
                    _job_elapsed = time.perf_counter() - _job_start
                    # Unknown error: treat as transient with retry progression
                    self.circuit_breaker.record_failure()
                    self._rate_limiter.record_result(success=False)

                    # Add retry metadata so job eventually reaches DLQ
                    job = self._prepare_for_retry(item, e)
                    max_retries = self.max_retries  # Standard limit for unknown errors
                    job_retry_count = job.get('retry_count', 0)

                    if job_retry_count >= max_retries:
                        log_warn(f"Job {jid} unexpected error exceeded max retries ({max_retries}), moving to DLQ: {e}")
                        fail_job(self.queue, item)
                        self.dlq.add(job, e, job_retry_count)
                        self._stats.record_failure(type(e).__name__, _job_elapsed, to_dlq=True)
                    else:
                        delay = job.get('next_retry_at', 0) - time.time()
                        log_warn(f"Job {jid} unexpected error (attempt {job_retry_count}/{max_retries}), retry in {delay:.1f}s: {e}")
                        self._requeue_with_metadata(job)
                        self._stats.record_failure(type(e).__name__, _job_elapsed, to_dlq=False)

            except Exception as e:
                # Worker loop error: log and continue
                log_error(f"Worker loop error: {e}")
                time.sleep(1)  # Avoid tight loop on persistent errors

    def _get_plex_client(self) -> 'PlexClient':
        """
        Get PlexClient with lazy initialization.

        Creates PlexClient on first use to avoid connecting to Plex
        until we actually need to process a job.

        Returns:
            PlexClient instance configured with URL, token, and timeouts
        """
        if self._plex_client is None:
            from plex.client import PlexClient  # lazy: heavy init (network connection)
            self._plex_client = PlexClient(
                url=self.config.plex_url,
                token=self.config.plex_token,
                connect_timeout=self.config.plex_connect_timeout,
                read_timeout=self.config.plex_read_timeout,
            )
        return self._plex_client

    def _get_caches(self) -> tuple[Optional['PlexCache'], Optional['MatchCache']]:
        """
        Get or create cache instances (lazy initialization).

        Caches are only created when data_dir is set. When data_dir is None,
        returns (None, None) and processing continues without caching.

        Returns:
            Tuple of (PlexCache or None, MatchCache or None)
        """
        if self._library_cache is None and self.data_dir is not None:
            from plex.cache import PlexCache, MatchCache  # lazy: heavy init
            cache_dir = os.path.join(self.data_dir, 'cache')
            self._library_cache = PlexCache(cache_dir)
            self._match_cache = MatchCache(cache_dir)
            log_debug(f"Initialized caches at {cache_dir}")
        return self._library_cache, self._match_cache

    def _get_metadata_updater(self):
        """Get MetadataUpdater with lazy initialization."""
        if self._metadata_updater is None:
            from worker.metadata_updater import MetadataUpdater  # lazy: test isolation
            self._metadata_updater = MetadataUpdater(self.config)
        return self._metadata_updater

    def _log_cache_stats(self):
        """Log cache hit/miss statistics."""
        library_cache, match_cache = self._get_caches()
        if library_cache is not None:
            stats = library_cache.get_stats()
            total = stats.get('hits', 0) + stats.get('misses', 0)
            if total > 0:
                hit_rate = stats['hits'] / total * 100
                log_debug(f"Library cache: {hit_rate:.1f}% hit rate ({stats['hits']} hits, {stats['misses']} misses)")
        if match_cache is not None:
            stats = match_cache.get_stats()
            total = stats.get('hits', 0) + stats.get('misses', 0)
            if total > 0:
                hit_rate = stats['hits'] / total * 100
                log_info(f"Match cache: {hit_rate:.1f}% hit rate ({stats['hits']} hits, {stats['misses']} misses)")

    def _process_job(self, job: dict) -> Optional[str]:
        """
        Process a sync job by updating Plex metadata.

        Finds the Plex item matching the job's file path and updates
        its metadata based on the update_type.

        Args:
            job: Job dict with scene_id, update_type, data
                - scene_id: Stash scene ID
                - update_type: Type of update (e.g., 'metadata')
                - data: Dict containing 'path' and metadata fields

        Returns:
            Match confidence level ('high' or 'low'), or None if job failed

        Raises:
            TransientError: For retry-able errors (network, timeout)
            PermanentError: For permanent failures (missing path, bad data)
        """
        import time as _time
        _start_time = _time.perf_counter()

        from plex.exceptions import PlexTemporaryError, PlexPermanentError, PlexNotFound, translate_plex_exception  # lazy: circular import
        from plex.matcher import find_plex_items_with_confidence, MatchConfidence  # lazy: imports plexapi
        from validation.obfuscation import obfuscate_path  # lazy: test isolation
        from sync_queue.operations import save_sync_timestamp  # lazy: test isolation
        from hooks.handlers import unmark_scene_pending  # lazy: test isolation

        _dbg = getattr(self.config, 'debug_logging', False)

        scene_id = job.get('scene_id')
        data = job.get('data', {})
        file_path = data.get('path')

        if not file_path:
            raise PermanentError(f"Job {scene_id} missing file path")

        if _dbg:
            log_info(f"[DEBUG] Processing scene {scene_id}, path: {obfuscate_path(file_path)}")

        try:
            client = self._get_plex_client()

            # Get library section(s) to search
            configured_libs = self.config.plex_libraries  # parsed comma-separated list
            if configured_libs:
                # Search only the configured libraries
                sections = []
                not_found = []
                for lib_name in configured_libs:
                    try:
                        sections.append(client.server.library.section(lib_name))
                    except Exception:
                        not_found.append(lib_name)
                if not_found:
                    log_warn(f"Libraries not found in Plex: {not_found}")
                if not sections:
                    raise PermanentError(f"None of the configured libraries found: {configured_libs}")
                log_trace(f"Searching {len(sections)} configured library(s): {[s.title for s in sections]}")
            else:
                # Search all libraries (slow)
                sections = client.server.library.sections()
                log_info(f"Searching all {len(sections)} libraries (set plex_library to speed up)")

            if _dbg:
                log_info(f"[DEBUG] Searching {len(sections)} section(s): {[s.title for s in sections]}")

            # Get caches for optimized matching
            library_cache, match_cache = self._get_caches()

            # Search library sections, collect ALL candidates
            all_candidates = []
            # Track which library section each candidate belongs to, so we can
            # write the confirmed match to match_cache after metadata update succeeds.
            _section_by_candidate_key: dict = {}
            for section in sections:
                try:
                    confidence, item, candidates = find_plex_items_with_confidence(
                        section,
                        file_path,
                        library_cache=library_cache,
                        match_cache=match_cache,
                        debug_logging=_dbg,
                    )
                    all_candidates.extend(candidates)
                    for c in candidates:
                        _section_by_candidate_key[c.key] = section.title
                    if _dbg:
                        log_info(f"[DEBUG] Section '{section.title}': {len(candidates)} candidate(s)")
                except PlexNotFound:
                    if _dbg:
                        log_info(f"[DEBUG] Section '{section.title}': no match")
                    continue  # No match in this section, try next

            # Deduplicate candidates (same item might be in multiple sections)
            seen_keys = set()
            unique_candidates = []
            for c in all_candidates:
                if c.key not in seen_keys:
                    seen_keys.add(c.key)
                    unique_candidates.append(c)

            if _dbg:
                log_info(f"[DEBUG] Dedup: {len(all_candidates)} total -> {len(unique_candidates)} unique candidate(s)")

            # Apply confidence scoring
            confidence = None
            if len(unique_candidates) == 0:
                raise PlexNotFound(f"Could not find Plex item for path: {obfuscate_path(file_path)}")
            elif len(unique_candidates) == 1:
                # HIGH confidence - single unique match
                confidence = 'high'
                plex_item = unique_candidates[0]
                if _dbg:
                    log_info(f"[DEBUG] HIGH confidence match: {plex_item.title}")
                self._get_metadata_updater().update(plex_item, data)
                # Write to match_cache AFTER metadata update succeeds.
                # This ensures the cache only records items that have been
                # fully synced. Writing before the update (as was previously
                # done inside find_plex_items_with_confidence) could cache
                # matches whose metadata was never pushed (e.g. process killed
                # mid-sync), causing subsequent cache-hits to find a Plex item
                # with auto-scanned metadata that "matches" an empty Stash
                # scene and silently skip the real metadata push.
                if match_cache is not None:
                    section_title = _section_by_candidate_key.get(plex_item.key)
                    if section_title:
                        item_key = getattr(plex_item, 'key', None) or str(getattr(plex_item, 'ratingKey', None))
                        if item_key:
                            match_cache.set_match(section_title, file_path, item_key)
            else:
                # LOW confidence - multiple matches
                confidence = 'low'
                paths = [c.media[0].parts[0].file if c.media and c.media[0].parts else c.key for c in unique_candidates]
                obfuscated_paths = [obfuscate_path(p) for p in paths]
                if self.config.strict_matching:
                    log_warn(
                        f"LOW CONFIDENCE SKIPPED: scene {scene_id} "
                        f"Stash path: {obfuscate_path(file_path)} "
                        f"Plex candidates ({len(unique_candidates)}): {obfuscated_paths}"
                    )
                    raise PermanentError(f"Low confidence match skipped (strict_matching=true)")
                else:
                    plex_item = unique_candidates[0]
                    log_warn(
                        f"LOW CONFIDENCE SYNCED: scene {scene_id} "
                        f"Chosen: {obfuscated_paths[0]} "
                        f"Other candidates: {obfuscated_paths[1:]}"
                    )
                    self._get_metadata_updater().update(plex_item, data)

            # Update sync timestamp after successful sync
            if self.data_dir is not None:
                save_sync_timestamp(self.data_dir, scene_id, time.time())

            # Remove from pending set (always, even on failure - will be re-added on retry)
            unmark_scene_pending(scene_id)

            # Log job processing time
            _elapsed = _time.perf_counter() - _start_time
            if _elapsed >= 1.0:
                log_info(f"_process_job took {_elapsed:.3f}s")
            else:
                log_trace(f"_process_job took {_elapsed:.3f}s")

            return confidence

        except (PlexTemporaryError, PlexPermanentError, PlexNotFound):
            unmark_scene_pending(scene_id)  # Allow re-enqueue on next hook
            raise
        except Exception as e:
            unmark_scene_pending(scene_id)
            raise translate_plex_exception(e)

